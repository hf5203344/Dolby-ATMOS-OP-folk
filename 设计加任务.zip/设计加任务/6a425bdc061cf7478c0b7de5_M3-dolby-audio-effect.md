# M3: 杜比音效链 — 任务列表

> 输入: `doc/detailed-design/M3-dolby-audio-effect.md`

---

## 1. audio_effects.xml — 静态模板

- [ ] 1.1 编写 `<libraries>` 节点：声明 `dap`(libswdap_sp.so)、`dvl`(libdlbvol_sp.so)、`gamedap`(libswgamedap_sp.so)
- [ ] 1.2 编写 `<effects>` 节点：声明 6 个 DVL 监听器（music/ring/alarm/system/notification）+ DAP + 游戏 DAP
- [ ] 1.3 编写 `<postprocess>` 节点：绑定 `music` 流 → `dap` + `dlb_music_listener`
- [ ] 1.4 验证所有 UUID 与 `libswdap_sp.so`、`libdlbvol_sp.so` 中注册的一致

## 2. merge_audio_effects() — 动态合并函数

- [ ] 2.1 读取现场 `/odm/etc/audio_effects.xml`，验证 XML 结构完整性
- [ ] 2.2 检测现场 XML 中已存在的杜比效果（`need_lib_*`、`need_fx_*` 标志位）
- [ ] 2.3 使用 awk 在 `</libraries>` 前插入缺失的库声明
- [ ] 2.4 使用 awk 在 `</effects>` 前插入缺失的效果声明
- [ ] 2.5 使用 awk 处理 `postprocess` 中的 `music` 流（插入或补全 DAP + DVL）
- [ ] 2.6 使用 awk 修正库路径为 basename（`/vendor/lib64/soundfx/` → `soundfx/`）
- [ ] 2.7 使用 awk 移除 OPlus AudioX 效果声明
- [ ] 2.8 合并后验证：输出 XML 包含 DAP UUID + `<apply effect="dap"/>` + `<apply effect="dlb_music_listener"/>`
- [ ] 2.9 幂等性保证：对已包含杜比效果的 XML 再次合并不重复添加
- [ ] 2.10 异常处理：损坏的 XML → 回退到模块内置版本，不崩溃

## 3. oplus.product.features_audiox.xml

- [ ] 3.1 编写替换 XML：声明 `oplus.software.audio.audioeffect_support` + `dolby_support`
- [ ] 3.2 放入 `my_product/etc/permissions/`

## 4. 原生库与二进制

- [ ] 4.1 从参考模块提取 `vendor.dolby.dms.service` → `system/vendor/bin/hw/`
- [ ] 4.2 从参考模块提取 DMS 运行时库：`libdlbdsservice_sp.so`、`libdapparamstorage_sp.so`、`libdlbpreg_sp.so`、`libdmshal.so`、`libspatializerparamstorage.so`
- [ ] 4.3 从参考模块提取 DMS 绑定库：`vendor.dolby.dms-V1-ndk.so`、`vendor.dolby_sp.hardware.dmssp@2.0.so`
- [ ] 4.4 从参考模块提取 DAP 音效库：`libswdap_sp.so`、`libdlbvol_sp.so`、`libswgamedap_sp.so` → `soundfx/`
- [ ] 4.5 从参考模块提取 `multimedia_dolby_dax_dflt.xml` → `vendor/etc/dolby/`

## 5. 测试

- [ ] 5.1 单元测试: `merge_audio_effects` 在模拟 XML 上正确合并
- [ ] 5.2 单元测试: 重复合并不产生重复声明（幂等性）
- [ ] 5.3 单元测试: 损坏 XML 输入 → 回退到内置版本
- [ ] 5.4 单元测试: AudioX 效果被正确移除
- [ ] 5.5 单元测试: UUID 常量与库中注册一致
- [ ] 5.6 集成测试: 安装后 `/odm/etc/audio_effects.xml` 包含 DAP + DVL
- [ ] 5.7 集成测试: `dumpsys media.audio_flinger | grep -A2 "dap"` 显示效果已注册
- [ ] 5.8 集成测试: `pidof vendor.dolby.dms.service` 返回有效 PID
- [ ] 5.9 集成测试: `service list | grep dolby` 显示 DMS AIDL 服务
- [ ] 5.10 端到端测试: 音乐播放 + DAP 开启 → 虚拟环绕可感知
- [ ] 5.11 端到端测试: 电影播放 + 电影预设 → 对白增强/低音增强可感知
- [ ] 5.12 端到端测试: 扬声器→蓝牙切换 → 音效不中断
- [ ] 5.13 异常测试: DMS 服务崩溃 → 系统音频不受影响
- [ ] 5.14 异常测试: 无 DMS 服务 → 解码器正常工作