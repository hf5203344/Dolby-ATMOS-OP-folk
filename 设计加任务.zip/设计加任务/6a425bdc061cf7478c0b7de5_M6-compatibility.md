# M6: 兼容性适配 — 任务列表

> 输入: `doc/detailed-design/M6-compatibility.md`

---

## 1. compat.sh — 设备信息函数

- [ ] 1.1 实现 `get_device_model()` — `getprop ro.product.model`
- [ ] 1.2 实现 `get_device_code()` — `getprop ro.product.device`
- [ ] 1.3 实现 `get_platform()` — `getprop ro.board.platform` 回退 `ro.hardware`
- [ ] 1.4 实现 `get_sdk_version()` — `getprop ro.build.version.sdk`
- [ ] 1.5 实现 `get_android_version()` — `getprop ro.build.version.release`

## 2. compat.sh — 兼容性检测函数

- [ ] 2.1 实现 `detect_root_solution()` — 通过 `$KSU`/`$APATCH`/`$MAGISK_VER` 识别
- [ ] 2.2 实现 `is_oplus_device()` — 通过 `ro.product.manufacturer` 判断
- [ ] 2.3 实现 `detect_audio_stack()` — 检测 `libaconfig_storage_read_api_cc.so` 或 `dvs-aidl-service.xml`
- [ ] 2.4 实现 `detect_conflicts()` — 检查 ViPER4Android/JamesDSP/其他杜比模块/AML/ACP
- [ ] 2.5 实现 `detect_hardware_dolby()` — 检查 `/vendor/etc/media_codecs*.xml` 中是否已有 `c2.dolby`

## 3. compat.sh — 安装前综合检测

- [ ] 3.1 实现 `pre_install_check()` — SDK ≥ 34 检查
- [ ] 3.2 实现 `pre_install_check()` — arm64-v8a 架构检查
- [ ] 3.3 实现 `pre_install_check()` — 冲突模块警告
- [ ] 3.4 实现 `pre_install_check()` — 硬件解码器覆盖提醒
- [ ] 3.5 实现 `pre_install_check()` — 非 OPlus 设备警告
- [ ] 3.6 实现 `pre_install_check()` — 返回错误计数

## 4. compat.sh — SELinux 策略

- [ ] 4.1 实现 `apply_sepolicy_patches()` — 通过 `magiskpolicy --live --apply` 注入
- [ ] 4.2 编写 `META-INF/sepolicy.rule` — DMS 服务访问 AudioFlinger
- [ ] 4.3 编写 `META-INF/sepolicy.rule` — Codec2 HAL 访问 MediaCodec
- [ ] 4.4 编写 `META-INF/sepolicy.rule` — DAP 效果库访问音频设备
- [ ] 4.5 编写 `META-INF/sepolicy.rule` — DAP 写入数据目录

## 5. compat.sh — 多机型参数

- [ ] 5.1 实现 `get_device_dap_params()` — PKG110 参数（48kHz 蓝牙）
- [ ] 5.2 实现 `get_device_dap_params()` — PKG120/PKG130 参数（96kHz 蓝牙）
- [ ] 5.3 实现 `get_device_dap_params()` — 默认回退参数

## 6. compat.sh — 运行时适配

- [ ] 6.1 实现 `select_dap_control_path()` — AIDL 栈 → `audioeffect_primary_dms_fallback`
- [ ] 6.2 实现 `select_dap_control_path()` — HIDL 栈 → `dms_hidl_primary_audioeffect_fallback`
- [ ] 6.3 实现 `select_dap_control_path()` — 未知 → `audioeffect_only`
- [ ] 6.4 实现 `check_dap_runtime()` — 检查 AudioFlinger 中 DAP UUID 是否存在
- [ ] 6.5 实现 `check_decoder_runtime()` — 检查 Codec2 中 Dolby 解码器是否存在

## 7. 测试

- [ ] 7.1 单元测试: `get_device_model()` 在不同设备上输出正确
- [ ] 7.2 单元测试: `detect_root_solution()` 在 KSU/Magisk/APatch 环境输出正确
- [ ] 7.3 单元测试: `detect_audio_stack()` 在 HIDL/AIDL 设备上识别正确
- [ ] 7.4 单元测试: `detect_conflicts()` 检测到 ViPER4Android
- [ ] 7.5 单元测试: `is_oplus_device()` 在一加/非一加设备上正确判断
- [ ] 7.6 单元测试: `pre_install_check()` 在 Android 13 上返回错误
- [ ] 7.7 单元测试: `get_device_dap_params()` 在 PKG110 上返回正确参数
- [ ] 7.8 单元测试: `select_dap_control_path()` 在 AIDL 设备上返回正确路径
- [ ] 7.9 集成测试: KSU 安装 → 兼容性检测通过
- [ ] 7.10 集成测试: Magisk 安装 → 兼容性检测通过
- [ ] 7.11 集成测试: APatch 安装 → 兼容性检测通过
- [ ] 7.12 集成测试: 冲突模块检测 → 安装时显示警告
- [ ] 7.13 集成测试: 非 OPlus 设备 → 安装时显示警告
- [ ] 7.14 集成测试: SELinux Enforcing → 策略补丁成功应用