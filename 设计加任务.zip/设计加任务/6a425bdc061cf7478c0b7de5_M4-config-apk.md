# M4: 配置 APK — 任务列表

> 输入: `doc/detailed-design/M4-config-apk.md`

---

## 1. 项目初始化

- [ ] 1.1 创建 Android 项目（Kotlin, minSdk=34, targetSdk=35, package=`com.dolby.atmos.oplus.folk`）
- [ ] 1.2 配置 `build.gradle.kts`（依赖：Material3、Navigation、Lifecycle、Coroutines）
- [ ] 1.3 创建项目目录结构（`ui/`、`domain/`、`data/`、`service/`、`i18n/`）
- [ ] 1.4 配置 `AndroidManifest.xml`（`MODIFY_DEFAULT_AUDIO_EFFECTS`、`BOOT_COMPLETED`、`FOREGROUND_SERVICE`）

## 2. Domain 层 — 数据模型

- [ ] 2.1 实现 `DolbyState` data class
- [ ] 2.2 实现 `Preset` enum（MOVIE/MUSIC/GAME/VOICE/CUSTOM）
- [ ] 2.3 实现 `EqualizerBand` data class
- [ ] 2.4 实现 `AudioDevice` data class + `DeviceType` enum
- [ ] 2.5 实现 `AppLanguage` enum（SYSTEM/CHINESE/ENGLISH）
- [ ] 2.6 定义 `DolbyRepository` interface（9 个方法）
- [ ] 2.7 定义 `SettingsRepository` interface

## 3. Data 层 — DAP 控制

- [ ] 3.1 实现 `DapEffectController` 类
- [ ] 3.2 实现 `initialize()` — 通过 `AudioEffect(UUID)` 绑定 DAP
- [ ] 3.3 实现 `setEnabled()` — 控制 `AudioEffect.enabled`
- [ ] 3.4 实现 `setPreset()` — 通过 `setParameter(PARAM_PRESET, ...)` 切换预设
- [ ] 3.5 实现 `setEqualizerBand()` — 通过 `setParameter(PARAM_EQ_BAND, ...)` 设置频段增益
- [ ] 3.6 实现 `release()` — 释放 AudioEffect 资源

## 4. Data 层 — DMS 通信

- [ ] 4.1 实现 `DmsBinder` 类
- [ ] 4.2 实现 `bind()` — 通过 `ServiceManager.getService()` 获取 DMS AIDL 接口（带重试）
- [ ] 4.3 实现 `getService()` — 返回 `IDms` 接口
- [ ] 4.4 实现 `unbind()` — 释放 DMS 连接
- [ ] 4.5 实现 `connectionState` StateFlow 暴露连接状态

## 5. Data 层 — 仓库实现

- [ ] 5.1 实现 `DmsRepositoryImpl`（实现 `DolbyRepository`）
- [ ] 5.2 实现 `getState()` — 从 DAP + DMS 聚合状态
- [ ] 5.3 实现 `setEnabled()` / `setPreset()` / `setEqualizerBand()` 等
- [ ] 5.4 实现 `observeDeviceChanges()` — 通过 `AudioDeviceMonitor` 监听
- [ ] 5.5 实现 `observeDolbyState()` — StateFlow 暴露状态
- [ ] 5.6 实现 `AudioDeviceMonitor` — 使用 `AudioManager` 监听设备变化
- [ ] 5.7 实现 `PreferencesManager` — SharedPreferences 封装
- [ ] 5.8 实现 `SettingsRepositoryImpl`（实现 `SettingsRepository`）

## 6. UI 层 — 主面板

- [ ] 6.1 实现 `MainViewModel`（dolbyState、isLoading、errorMessage）
- [ ] 6.2 实现 `toggleDolby()` — 开关切换 + 回滚
- [ ] 6.3 实现 `setPreset()` — 预设切换 + 回滚
- [ ] 6.4 实现 `MainFragment` 布局：总开关 + 预设卡片 + 设备状态栏
- [ ] 6.5 实现 `DolbySwitch` 自定义组件
- [ ] 6.6 实现 `PresetCard` 自定义组件（横向滚动 RecyclerView）
- [ ] 6.7 实现 `DeviceStatusBar` 自定义组件（输出设备类型 + 采样率 + DAP 状态）

## 7. UI 层 — 均衡器

- [ ] 7.1 实现 `EqualizerViewModel`（10 段 bands、isDirty）
- [ ] 7.2 实现 `setBandGain()` — 单段增益调节（clamp -12~+12dB）
- [ ] 7.3 实现 `resetToFlat()` — 全部归零
- [ ] 7.4 实现 `applyPresetCurve()` — 摇滚/流行/古典/爵士/人声/平坦 6 种曲线
- [ ] 7.5 实现 `EqualizerFragment` 布局：均衡器预设 Chip + 10 段垂直滑块 + 频率标签 + 重置按钮
- [ ] 7.6 实现 `EqualizerSlider` 自定义组件

## 8. UI 层 — 设置

- [ ] 8.1 实现 `SettingsViewModel`（语言、开机自启、蓝牙独立配置）
- [ ] 8.2 实现 `SettingsFragment` 布局：语言选择器 + 开关 + 关于信息
- [ ] 8.3 实现 `LanguageSelector` 自定义组件（跟随系统 / 中文 / English）
- [ ] 8.4 实现语言切换逻辑（`AppCompatDelegate.setApplicationLocales`）

## 9. Service 层

- [ ] 9.1 实现 `DolbyControlService` 前台服务
- [ ] 9.2 在 `onCreate()` 中初始化 DAP + 恢复上次配置
- [ ] 9.3 实现前台通知（最低限度）
- [ ] 9.4 实现 `BootReceiver` — 监听 `BOOT_COMPLETED` 启动服务

## 10. 国际化

- [ ] 10.1 编写 `res/values/strings.xml`（英文默认）
- [ ] 10.2 编写 `res/values-zh/strings.xml`（中文）
- [ ] 10.3 所有 UI 文字引用 `@string/` 资源

## 11. 主题

- [ ] 11.1 定义 `Color.kt`（Material 3 Dark 主题色板）
- [ ] 11.2 定义 `Type.kt`（字体样式）
- [ ] 11.3 定义 `Theme.kt`（`DolbyAtmosTheme`）

## 12. APK 集成

- [ ] 12.1 使用 platform 签名 APK
- [ ] 12.2 创建 `com.dolby.atmos.oplus.folk.xml` 权限声明文件
- [ ] 12.3 放入 `system/system_ext/priv-app/DolbyAtmosControl/`

## 13. 测试

- [ ] 13.1 单元测试: `DapEffectController` Mock AudioEffect 验证
- [ ] 13.2 单元测试: `MainViewModel` 开关/预设切换 + 回滚逻辑
- [ ] 13.3 单元测试: `EqualizerViewModel` 增益 clamp + 重置 + 预设曲线
- [ ] 13.4 单元测试: `PreferencesManager` 读写一致性
- [ ] 13.5 UI 测试: 主界面渲染（开关、预设卡片、设备状态）
- [ ] 13.6 UI 测试: 开关切换动画流畅
- [ ] 13.7 UI 测试: 预设切换高亮正确
- [ ] 13.8 UI 测试: 均衡器滑块拖动实时更新
- [ ] 13.9 UI 测试: 语言切换所有界面文字更新
- [ ] 13.10 集成测试: 真机 DAP 开关 → 音频有可感知变化
- [ ] 13.11 集成测试: 插拔耳机 → 设备状态更新
- [ ] 13.12 集成测试: 蓝牙连接 → 设备名显示 + 独立配置
- [ ] 13.13 集成测试: 开机自启 → 服务自动恢复配置
- [ ] 13.14 异常测试: DMS 不可用 → 降级 AudioEffect only, 不崩溃
- [ ] 13.15 异常测试: 快速切换预设 → 无 ANR