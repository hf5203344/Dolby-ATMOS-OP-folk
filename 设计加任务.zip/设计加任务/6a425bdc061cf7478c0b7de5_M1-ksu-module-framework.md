# M1: KSU 模块打包框架 — 任务列表

> 输入: `doc/detailed-design/M1-ksu-module-framework.md`

---

## 1. module.prop

- [ ] 1.1 编写 `module.prop`，定义 `id=dolby_atmos_oplus_folk`、`version=v1.0.0`、`versionCode=100`
- [ ] 1.2 填写 `name`、`author`、`description` 中英双语字段

## 2. customize.sh — 安装脚本

- [ ] 2.1 初始化环境变量（`MODPATH`、`TMPDIR`、`ARCH`、`API`）
- [ ] 2.2 实现 `ui_print()` 和 `abort()` 工具函数
- [ ] 2.3 `source` 引入 M6 的 `compat.sh`
- [ ] 2.4 阶段 1: 实现 `detect_root_solution()` — 识别 KSU/Magisk/APatch
- [ ] 2.5 阶段 1: 实现 `detect_android_version()` — SDK ≥ 34 检查
- [ ] 2.6 阶段 1: 实现 `detect_platform()` — 芯片平台识别（sm8650/sm8750）
- [ ] 2.7 阶段 1: 实现 `detect_device()` — 设备型号 + OPlus 判断
- [ ] 2.8 阶段 1: 实现 `detect_architecture()` — arm64-v8a 检查
- [ ] 2.9 阶段 1: 实现 `detect_audio_stack()` — HIDL/AIDL 检测并写入 `.audio_stack_type`
- [ ] 2.10 阶段 2: 音量键选择逻辑（`getevent` 监听 + 10 秒超时）
- [ ] 2.11 阶段 2: 音量上键 → 打开 GitHub 更新页 + `INSTALL_MODE=update`
- [ ] 2.12 阶段 2: 音量下键/超时 → `INSTALL_MODE=direct`
- [ ] 2.13 阶段 3: 实现 `clean_old_artifacts()` — 清理旧版 APK 和探针残留
- [ ] 2.14 阶段 4: 实现 `perm_recursive()` 和 `perm_one()` 函数
- [ ] 2.15 阶段 4: 设置所有目录和文件权限（vendor/bin、vendor/lib64、soundfx、odm/etc、my_product、system_ext）
- [ ] 2.16 阶段 5: 调用 M3 的 `merge_audio_effects()` 或回退到内置版本
- [ ] 2.17 阶段 6: 安装完成提示 + 写入 `.install_info` 记录

## 3. post-fs-data.sh — 挂载后脚本

- [ ] 3.1 实现 `log()` 函数，写入 `post-fs-data.log`
- [ ] 3.2 实现 `clear_package_cache()` — 清理 DolbyAtmosControl APK 缓存
- [ ] 3.3 实现 `setup_dolby_data_dir()` — 创建 `/data/vendor/dolby`，权限 0770, owner media:media
- [ ] 3.4 实现 `setup_diag_dir()` — 创建 `/storage/emulated/0/dolbylog`
- [ ] 3.5 调用 M6 的 `apply_sepolicy_patches()`（如果可用）

## 4. service.sh — 服务启动脚本

- [ ] 4.1 实现 `log()`、`file_sig()`、`same_file_overlay()`、`context_has()`、`wait_prop()`、`start_once()` 工具函数
- [ ] 4.2 清理探针残留（`.probe_lock`、`boot_probe_state.txt` 等）
- [ ] 4.3 确保 DAP 数据目录权限（`/data/vendor/dolby`）
- [ ] 4.4 挂载 OPlus AudioX 特性 XML（`mount --bind`）
- [ ] 4.5 验证 VINTF manifest 挂载（签名比较 + SELinux 上下文）
- [ ] 4.6 等待 APEX 信息加载并挂载（`apex-info-list.xml`）
- [ ] 4.7 等待 `servicemanager` 和 `hwservicemanager` 就绪
- [ ] 4.8 启动 DMS 服务（`start_once vendor.dolby.dms.service`）
- [ ] 4.9 启动 Codec2 HAL 服务（`start_once vendor.dolby_sp.media.c2@1.0-service`）
- [ ] 4.10 写入系统属性（`resetprop ro.oplus.audio.effect.type dolby`）

## 5. 其他文件

- [ ] 5.1 编写 `system.prop`
- [ ] 5.2 编写 `uninstall.sh`（停止服务、卸载挂载点、恢复属性、清理数据目录）
- [ ] 5.3 编写 `META-INF/com/google/android/updater-script`（`#MAGISK`）
- [ ] 5.4 编写 `META-INF/com/google/android/update-binary`（Magisk 包装器）

## 6. 测试

- [ ] 6.1 单元测试: `module.prop` 在 KSU Manager 中正确解析
- [ ] 6.2 单元测试: 6 个 `detect_*` 函数在目标设备上输出正确
- [ ] 6.3 单元测试: `perm_recursive` / `perm_one` 权限设置正确
- [ ] 6.4 单元测试: `clean_old_artifacts` 正确清理旧文件
- [ ] 6.5 集成测试: KSU 安装 → 重启 → 模块出现在列表中
- [ ] 6.6 集成测试: Magisk 安装 → 重启 → 模块出现在列表中
- [ ] 6.7 集成测试: APatch 安装 → 重启 → 模块出现在列表中
- [ ] 6.8 集成测试: 音量键选择逻辑正确触发
- [ ] 6.9 集成测试: 不兼容设备（Android 13）安装中止
- [ ] 6.10 冒烟测试: 安装后正常开机，无 ANR/崩溃
- [ ] 6.11 冒烟测试: `service.log` 和 `post-fs-data.log` 有内容
- [ ] 6.12 冒烟测试: VINTF manifest 挂载验证通过
- [ ] 6.13 冒烟测试: `getprop ro.oplus.audio.effect.type` 输出 `dolby`