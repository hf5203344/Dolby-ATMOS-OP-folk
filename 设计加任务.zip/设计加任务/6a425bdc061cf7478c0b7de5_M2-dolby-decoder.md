# M2: 杜比解码器 — 任务列表

> 输入: `doc/detailed-design/M2-dolby-decoder.md`

---

## 1. media_codecs_c2.xml

- [ ] 1.1 编写 `<Decoders>` 根节点
- [ ] 1.2 注册 `c2.dolby.eac3.decoder` — 支持 `audio/ac3`（6ch / 32-48kHz / 640kbps）
- [ ] 1.3 注册 `c2.dolby.eac3.decoder` — 支持 `audio/eac3`（8ch / 32-48kHz / 6144kbps）
- [ ] 1.4 注册 `c2.dolby.eac3.decoder` — 支持 `audio/eac3-joc`（16ch / 48kHz / 6144kbps）
- [ ] 1.5 注册 `c2.dolby.ac4.decoder` — 支持 `audio/ac4`（16ch / 48kHz / 2688kbps）
- [ ] 1.6 为每个解码器添加 `<Alias>` 标签（OMX 兼容）和 `<Attribute name="software-codec" />`

## 2. c2_manifest_vendor_audio.xml

- [ ] 2.1 声明 `android.hardware.media.c2` HIDL HAL（`default2` + `default1`）
- [ ] 2.2 声明 `vendor.dolby.dms` AIDL HAL（`IDms/default`）
- [ ] 2.3 设置 `transport=hwbinder` 和正确的 `fqname`

## 3. 原生库部署

- [ ] 3.1 从参考模块提取 `libcodec2_soft_ac4dec_sp.so` → 放入 `system/vendor/lib64/`
- [ ] 3.2 从参考模块提取 `libcodec2_soft_ddpdec_sp.so` → 放入 `system/vendor/lib64/`
- [ ] 3.3 从参考模块提取 `libcodec2_soft_common.so` → 放入 `system/vendor/lib64/`
- [ ] 3.4 从参考模块提取 `libcodec2_store_dolby_sp.so` → 放入 `system/vendor/lib64/`
- [ ] 3.5 从参考模块提取 `libdeccfg_sp.so` → 放入 `system/vendor/lib64/`
- [ ] 3.6 从参考模块提取 `libYokiScale.so` → 放入 `system/vendor/lib64/`
- [ ] 3.7 计算所有 .so 文件的 SHA256 并记录到 `checksums.txt`

## 4. Codec2 HIDL 服务

- [ ] 4.1 从参考模块提取 `vendor.dolby_sp.media.c2@1.0-service` → 放入 `system/vendor/bin/hw/`
- [ ] 4.2 确认二进制为 arm64-v8a ELF，无缺失动态链接

## 5. 测试

- [ ] 5.1 单元测试: 安装后 `pidof vendor.dolby_sp.media.c2@1.0-service` 返回有效 PID
- [ ] 5.2 单元测试: `lshal debug android.hardware.media.c2@1.0::IComponentStore/default1` 返回服务信息
- [ ] 5.3 单元测试: `dumpsys media.codec2 | grep "c2.dolby"` 列出两个解码器
- [ ] 5.4 单元测试: `dumpsys media.codec2 c2.dolby.ac4.decoder` 显示正确属性
- [ ] 5.5 集成测试: VLC 播放 AC-4 MKV 文件有声音
- [ ] 5.6 集成测试: MX Player HW+ 解码 E-AC-3 正常
- [ ] 5.7 集成测试: 同时播放 AAC + AC-4，解码器互不干扰
- [ ] 5.8 性能测试: AC-4 16ch CPU 占用 < 15%
- [ ] 5.9 性能测试: E-AC-3-JOC 解码延迟 < 50ms
- [ ] 5.10 兼容性测试: Android 14/15/16 上解码器均正常
- [ ] 5.11 兼容性测试: Magisk/APatch 安装后解码器正常