# M5: 诊断工具 — 任务列表

> 输入: `doc/detailed-design/M5-diagnostics.md`

---

## 1. action.sh 脚本框架

- [ ] 1.1 定义路径常量（`MODDIR`、`OUTDIR`、`TIMESTAMP`、各类输出文件）
- [ ] 1.2 实现 `log()` 和 `log_console()` 函数
- [ ] 1.3 实现 `file_exists()`、`service_running()`、`prop_get()` 工具函数
- [ ] 1.4 创建输出目录（`/storage/emulated/0/dolbylog/` + `crash_*/`）

## 2. 阶段 1: 系统信息采集

- [ ] 2.1 采集设备型号、代号、制造商
- [ ] 2.2 采集 Android 版本、SDK 版本、内核版本
- [ ] 2.3 采集芯片平台、CPU 架构、SELinux 状态

## 3. 阶段 2: 模块状态检查

- [ ] 3.1 读取并记录 `module.prop`（id、version、author）
- [ ] 3.2 读取并记录 `.install_info`（安装时间、Root 方案、Android 版本等）
- [ ] 3.3 读取并记录 `.audio_stack_type`（HIDL/AIDL）

## 4. 阶段 3: 服务状态检查

- [ ] 4.1 检查 Codec2 HAL 服务进程 + 可执行文件
- [ ] 4.2 检查 DMS 服务进程 + 可执行文件
- [ ] 4.3 检查 HIDL 服务注册（`lshal debug`）
- [ ] 4.4 检查 AIDL 服务注册（`service list | grep dolby`）

## 5. 阶段 4: 文件完整性校验

- [ ] 5.1 校验 6 个解码器库（`libcodec2_soft_*.so`、`libcodec2_soft_common.so`、`libcodec2_store_dolby_sp.so`、`libdeccfg_sp.so`、`libYokiScale.so`）
- [ ] 5.2 校验 3 个 DAP 音效库（`libswdap_sp.so`、`libdlbvol_sp.so`、`libswgamedap_sp.so`）
- [ ] 5.3 校验 7 个 DMS 库（`libdlbdsservice_sp.so`、`libdapparamstorage_sp.so`、`libdlbpreg_sp.so`、`libdmshal.so`、`libspatializerparamstorage.so`、`vendor.dolby.dms-V1-ndk.so`、`vendor.dolby_sp.hardware.dmssp@2.0.so`）
- [ ] 5.4 校验 5 个配置文件（`audio_effects.xml`、`media_codecs_c2.xml`、`c2_manifest_vendor_audio.xml`、`multimedia_dolby_dax_dflt.xml`、`oplus.product.features_audiox.xml`）
- [ ] 5.5 校验 APK 文件存在

## 6. 阶段 5: 运行时检查

- [ ] 6.1 检查 `/data/vendor/dolby` 目录存在性、权限、文件数
- [ ] 6.2 检查系统属性（`ro.oplus.audio.effect.type`、`ro.oplus.audio.dolby.equalizer_support`）
- [ ] 6.3 检查 SELinux 上下文（`libswdap_sp.so`、`libdlbpreg_sp.so`）
- [ ] 6.4 检查挂载点（VINTF manifest、AudioX feature XML）
- [ ] 6.5 检查 AudioFlinger 效果（`dumpsys media.audio_flinger | grep -i dolby`）
- [ ] 6.6 检查 MediaCodec 解码器（`dumpsys media.codec2 | grep -i dolby`）

## 7. 阶段 6: Logcat 采集

- [ ] 7.1 采集 Dolby 相关日志（`logcat -d -t 1000 | grep -iE "dolby|dap|dlb|dms|swdap|ac4|eac3"`）
- [ ] 7.2 采集事件日志（`logcat -b events -d -t 500 | grep -iE "audio|dolby|media"`）

## 8. 阶段 7: Tombstone 分析

- [ ] 8.1 搜索与 Dolby 相关的 tombstone 文件
- [ ] 8.2 提取关键信息（pid、signal、backtrace、Abort、Fatal）
- [ ] 8.3 采集 ANR traces

## 9. 阶段 8: 包管理器状态

- [ ] 9.1 检查 `com.dolby.atmos.oplus.folk` 是否已安装
- [ ] 9.2 获取 APK 路径

## 10. 阶段 9: 分类报告

- [ ] 10.1 实现 `check_pass()`、`check_warn()`、`check_fail()` 函数
- [ ] 10.2 核心服务检查（Codec2 HAL + DMS）
- [ ] 10.3 解码器检查（AC-4 + E-AC-3 库）
- [ ] 10.4 音效检查（DAP + DVL 库）
- [ ] 10.5 配置检查（audio_effects + media_codecs）
- [ ] 10.6 运行时检查（DAP 数据目录 + 系统属性）
- [ ] 10.7 APK 检查
- [ ] 10.8 统计通过/警告/失败计数
- [ ] 10.9 根据结果输出建议

## 11. 阶段 10: 日志打包

- [ ] 11.1 汇总所有输出文件路径
- [ ] 11.2 控制台输出摘要

## 12. 测试

- [ ] 12.1 单元测试: 脚本正常执行，退出码 0
- [ ] 12.2 单元测试: 输出目录创建成功
- [ ] 12.3 单元测试: 报告文件非空
- [ ] 12.4 单元测试: 删除 .so 后报告显示"缺失"
- [ ] 12.5 单元测试: 停止 DMS 后报告显示"未运行"
- [ ] 12.6 单元测试: 分类统计正确
- [ ] 12.7 集成测试: 模块完全正常 → 全部通过
- [ ] 12.8 集成测试: 部分缺失 → 准确报告缺失项
- [ ] 12.9 集成测试: 无 DMS 模式 → 标记为警告
- [ ] 12.10 集成测试: 无 root → 优雅失败