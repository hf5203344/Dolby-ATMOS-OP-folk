# M2: 杜比解码器 — 详细设计文档

> **版本:** v1.0 | **日期:** 2026-06-29 | **状态:** 详细设计

---

## 1. 模块概述

### 1.1 职责

M2 负责杜比全景声解码器的集成，包括：

- 提供 AC-3、E-AC-3、E-AC-3-JOC、AC-4 四种格式的软件解码器
- 通过 Codec2 HIDL 框架注册解码器到 Android MediaCodec 系统
- 声明 VINTF manifest 使解码服务可被系统发现
- 管理解码器原生库（.so）的部署和权限

### 1.2 依赖关系

| 方向 | 模块 | 说明 |
|------|------|------|
| 上游依赖 | M1 | 依赖 M1 的目录结构、权限设置、service.sh 服务启动 |
| 下游依赖 | 无 | M2 是独立功能模块 |

### 1.3 解码器能力矩阵

| 格式 | MIME Type | 最大声道 | 采样率 | 最大码率 | 解码器名称 |
|------|-----------|----------|--------|----------|-----------|
| AC-3 | `audio/ac3` | 6 | 32/44.1/48 kHz | 640 kbps | `c2.dolby.ac3.decoder` (alias of eac3 decoder) |
| E-AC-3 | `audio/eac3` | 8 | 32/44.1/48 kHz | 6144 kbps | `c2.dolby.eac3.decoder` |
| E-AC-3-JOC | `audio/eac3-joc` | 16 | 48 kHz | 6144 kbps | `c2.dolby.eac3.decoder` |
| AC-4 | `audio/ac4` | 16 | 48 kHz | 2688 kbps | `c2.dolby.ac4.decoder` |

---

## 2. 文件清单与实现

### 2.1 文件清单

```
system/
├── odm/etc/
│   └── media_codecs_c2.xml                            # 解码器注册配置
├── vendor/
│   ├── bin/hw/
│   │   └── vendor.dolby_sp.media.c2@1.0-service       # Codec2 HIDL 服务守护进程
│   ├── etc/vintf/manifest/
│   │   └── c2_manifest_vendor_audio.xml               # VINTF HAL 服务声明
│   └── lib64/
│       ├── libcodec2_soft_ac4dec_sp.so                # AC-4 软件解码器
│       ├── libcodec2_soft_ddpdec_sp.so                # Dolby Digital Plus (E-AC-3) 解码器
│       ├── libcodec2_soft_common.so                   # Codec2 通用辅助库
│       ├── libcodec2_store_dolby_sp.so                # 杜比组件存储
│       ├── libdeccfg_sp.so                            # 解码器配置
│       └── libYokiScale.so                            # Yoki 音频缩放
```

### 2.2 `media_codecs_c2.xml` — 解码器注册

```xml
<?xml version="1.0" encoding="utf-8" ?>
<!--
    Dolby Atmos OnePlus folk popularization
    Codec2 解码器注册配置
    基于 PJD110 设备提取，适配 PKG110 (一加 ACE5)
-->
<Included>
    <Decoders>
        <!-- DOLBY_UDC: Dolby Digital / Dolby Digital Plus / Dolby Atmos -->
        <MediaCodec name="c2.dolby.eac3.decoder" >
            <Type name="audio/ac3">
                <Alias name="OMX.dolby.ac3.decoder" />
                <Limit name="channel-count" max="6" />
                <Limit name="sample-rate" ranges="32000,44100,48000" />
                <Limit name="bitrate" range="32000-640000" />
            </Type>
            <Type name="audio/eac3">
                <Alias name="OMX.dolby.eac3.decoder" />
                <Limit name="channel-count" max="8" />
                <Limit name="sample-rate" ranges="32000,44100,48000" />
                <Limit name="bitrate" range="32000-6144000" />
            </Type>
            <Type name="audio/eac3-joc">
                <Alias name="OMX.dolby.eac3-joc.decoder" />
                <Limit name="channel-count" max="16" />
                <Limit name="sample-rate" ranges="48000" />
                <Limit name="bitrate" range="32000-6144000" />
            </Type>
            <Attribute name="software-codec" />
        </MediaCodec>

        <!-- DOLBY_AC4: Dolby AC-4 -->
        <MediaCodec name="c2.dolby.ac4.decoder" type="audio/ac4">
            <Alias name="OMX.dolby.ac4.decoder" />
            <Limit name="channel-count" max="16" />
            <Limit name="sample-rate" ranges="48000" />
            <Limit name="bitrate" range="16000-2688000" />
            <Attribute name="software-codec" />
        </MediaCodec>
    </Decoders>
</Included>
```

**设计说明:**

- `<Attribute name="software-codec" />` 标记为软件解码器，Android 框架会优先使用硬件解码器（如果存在），仅在硬件不支持时回退到本模块
- `<Alias>` 标签提供 OMX 兼容别名，确保使用旧版 MediaCodec API 的应用也能发现解码器
- `<Limit>` 标签声明解码器能力边界，系统在创建解码器实例前会验证输入格式是否在范围内

---

### 2.3 `c2_manifest_vendor_audio.xml` — VINTF HAL 声明

```xml
<!--
    Dolby Atmos OnePlus folk popularization
    VINTF manifest: Codec2 HIDL 服务声明
    保留 Qualcomm 音频 C2 default2 声明，添加 Dolby C2 default1 实例
-->
<manifest version="1.0" type="device">
    <hal format="hidl">
        <name>android.hardware.media.c2</name>
        <transport>hwbinder</transport>
        <fqname>@1.0::IComponentStore/default2</fqname>
        <fqname>@1.0::IComponentStore/default1</fqname>
    </hal>
    <hal format="aidl">
        <name>vendor.dolby.dms</name>
        <version>1</version>
        <fqname>IDms/default</fqname>
    </hal>
</manifest>
```

**设计说明:**

- `default2` 保留原厂 Qualcomm 音频 Codec2 服务声明，确保不破坏原有解码器
- `default1` 新增 Dolby Codec2 HIDL 服务实例，由 `vendor.dolby_sp.media.c2@1.0-service` 守护进程注册
- `vendor.dolby.dms IDms/default` 为 M3 音效模块的 DMS 服务声明（AIDL 格式），放在此文件中避免创建单独的 VINTF 文件

---

### 2.4 解码器原生库映射

| 文件 | 大小（参考） | SHA256 | 用途 |
|------|-------------|--------|------|
| `libcodec2_soft_ac4dec_sp.so` | ~2.5 MB | 待确认 | AC-4 解码器核心实现 |
| `libcodec2_soft_ddpdec_sp.so` | ~1.8 MB | 待确认 | Dolby Digital Plus / E-AC-3-JOC 解码器 |
| `libcodec2_soft_common.so` | ~200 KB | 待确认 | Codec2 通用辅助函数（buffer 管理、时间戳处理） |
| `libcodec2_store_dolby_sp.so` | ~300 KB | 待确认 | 杜比 Codec2 组件存储（参数持久化） |
| `libdeccfg_sp.so` | ~150 KB | 待确认 | 解码器运行时配置 |
| `libYokiScale.so` | ~500 KB | 待确认 | Yoki 音频缩放库（采样率转换、声道映射） |

**SHA256 待确认说明:** 这些库从参考模块直接提取，首次构建时需计算实际 SHA256 值，并记录到 `module.prop` 或单独的 `checksums.txt` 中用于完整性校验。

---

### 2.5 Codec2 HIDL 服务守护进程

`vendor.dolby_sp.media.c2@1.0-service` 是一个预编译的 ELF 可执行文件，负责：

1. 通过 HIDL `android.hardware.media.c2@1.0::IComponentStore` 接口注册解码器
2. 加载 `libcodec2_store_dolby_sp.so` 作为组件存储后端
3. 响应 MediaCodec 框架的解码器查询和实例化请求
4. 管理解码器生命周期（创建、配置、解码、释放）

**启动参数:** 无需额外参数，由 `service.sh` 直接调用：
```bash
/vendor/bin/hw/vendor.dolby_sp.media.c2@1.0-service &
```

**运行验证:**

```bash
# 检查服务是否启动
pidof vendor.dolby_sp.media.c2@1.0-service

# 检查 HIDL 服务注册
lshal debug android.hardware.media.c2@1.0::IComponentStore/default1

# 检查解码器列表
dumpsys media.codec2 | grep -A5 "dolby"
```

---

## 3. 解码流程

### 3.1 解码器发现与选择流程

```
┌─────────────────────────────────────────────────────────────────┐
│ 应用请求解码 (MediaCodec.createDecoderByType("audio/ac4"))     │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│ MediaCodec 框架查询 Codec2 组件存储                             │
│ 1. 读取 /vendor/etc/media_codecs_c2.xml                        │
│ 2. 读取 /odm/etc/media_codecs_c2.xml (模块覆盖)                │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│ HIDL 服务发现 (hwservicemanager)                                │
│ 1. 查询 android.hardware.media.c2@1.0::IComponentStore/default1│
│ 2. 返回 vendor.dolby_sp.media.c2@1.0-service                   │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│ 组件存储返回解码器信息                                          │
│ c2.dolby.ac4.decoder: audio/ac4, max 16ch, 48kHz, software     │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│ Codec2 框架创建解码器实例                                       │
│ 1. 加载 libcodec2_soft_ac4dec_sp.so                            │
│ 2. 调用 C2Component::init() 初始化                             │
│ 3. 调用 C2Component::setParameters() 配置                      │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│ 解码循环                                                        │
│ C2Component::queue() → process() → onWorkDone()                │
│ 输入: 编码的 AC-4 bitstream                                     │
│ 输出: PCM 16-bit interleaved                                    │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 解码器实例化关键代码路径

```
MediaCodec.createByCodecName("c2.dolby.ac4.decoder")
  → CCodec::initiateAllocateComponent()
    → IComponentStore::createComponent("c2.dolby.ac4.decoder", ...)
      → libcodec2_store_dolby_sp.so: CreateComponent()
        → new C2SoftAc4Dec()  (libcodec2_soft_ac4dec_sp.so)
          → C2SoftAc4Dec::init()
            → 注册 input/output C2Port
            → 设置 supported sample rates, channel counts, bitrates
```

---

## 4. 模块间接口

### 4.1 对 M1 的依赖

| 接口 | 说明 |
|------|------|
| 目录结构 | M2 的文件部署在 `$MODPATH/system/vendor/` 和 `$MODPATH/system/odm/` |
| 权限设置 | 依赖 M1 的 `perm_recursive` / `perm_one` 设置文件权限和 SELinux 上下文 |
| 服务启动 | 依赖 M1 的 `service.sh` 调用 `start_once` 启动 Codec2 HAL 守护进程 |
| 环境变量 | 依赖 `$MODPATH` 和 `$MODDIR` 定位模块文件 |

### 4.2 对 M3 的接口

| 接口 | 说明 |
|------|------|
| VINTF manifest | M2 的 `c2_manifest_vendor_audio.xml` 包含 DMS AIDL 服务声明，M3 依赖此声明 |
| 共享库 | `libYokiScale.so` 和 `libdeccfg_sp.so` 被 M3 的 DAP 引擎间接引用 |

### 4.3 对 M6 的接口

| 接口 | 说明 |
|------|------|
| 解码器可用性检测 | M6 在安装时检测设备是否已有硬件 AC-4 解码器，M2 提供覆盖策略 |

---

## 5. 测试方案

### 5.1 单元测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| Codec2 服务启动 | 安装模块后重启，执行 `pidof vendor.dolby_sp.media.c2@1.0-service` | 返回有效 PID |
| HIDL 服务注册 | 执行 `lshal debug android.hardware.media.c2@1.0::IComponentStore/default1` | 返回服务信息，无错误 |
| 解码器列表 | 执行 `dumpsys media.codec2 \| grep "c2.dolby"` | 列出 `c2.dolby.ac4.decoder` 和 `c2.dolby.eac3.decoder` |
| 解码器属性 | 执行 `dumpsys media.codec2 c2.dolby.ac4.decoder` | 显示正确的 MIME type、声道数、采样率范围 |
| AC-4 解码 | 使用 `mediapc` 工具或 CTS 测试套件 | 解码成功，输出 PCM 数据 |

### 5.2 集成测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| VLC 播放 AC-4 视频 | 在 VLC 中打开 AC-4 编码的 MKV 文件 | 有声音输出，无 crash |
| MX Player 播放 E-AC-3 | 在 MX Player 中使用 HW+ 解码器播放 | 有声音输出，音视频同步 |
| 系统 MediaCodec 列表 | 执行 `adb shell dumpsys media.codec2` | 杜比解码器出现在列表中，状态为已注册 |
| 与其他解码器共存 | 同时播放 AAC 和 AC-4 音频 | 两个解码器独立工作，互不干扰 |
| 解码器卸载 | 移除模块后执行 `dumpsys media.codec2` | 杜比解码器不再出现 |

### 5.3 性能测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| AC-4 16ch CPU 占用 | 播放 16 声道 AC-4 内容，使用 `top` 监控 | CPU 占用 < 15% |
| E-AC-3-JOC CPU 占用 | 播放带 Atmos 的 E-AC-3-JOC 内容 | CPU 占用 < 10% |
| 内存占用 | 使用 `dumpsys meminfo` 监控解码器进程 | 内存 < 100 MB |
| 解码延迟 | 使用 `mediapc` 工具测量 | 延迟 < 50ms |

### 5.4 兼容性测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| Android 14 兼容 | 在 Android 14 设备上安装 | 解码器正常工作 |
| Android 15 兼容 | 在 Android 15 设备上安装 | 解码器正常工作 |
| Android 16 兼容 | 在一加 ACE5 (Android 16) 上安装 | 解码器正常工作 |
| Magisk 兼容 | 通过 Magisk 安装 | 解码器正常工作 |
| APatch 兼容 | 通过 APatch 安装 | 解码器正常工作 |

---

## 6. 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v1.0 | 2026-06-29 | 初始版本，基于参考模块 dolbycodec2hidl H1.32 解码器组件 |