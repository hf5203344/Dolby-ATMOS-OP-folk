# M4: 配置 APK — 详细设计文档

> **版本:** v1.0 | **日期:** 2026-06-29 | **状态:** 详细设计

---

## 1. 模块概述

### 1.1 职责

M4 是面向用户的杜比全景声配置 APK，负责：

- 杜比音效总开关（启用/禁用 DAP 处理）
- 5 种预设模式切换（电影/音乐/游戏/语音/自定义）
- 10 段图形化均衡器调节
- 当前输出设备信息和杜比状态显示
- 中英文语言切换
- 开机自启配置记忆

### 1.2 依赖关系

| 方向 | 模块 | 说明 |
|------|------|------|
| 上游依赖 | M3 | 依赖 M3 的 DMS AIDL 服务和 AudioEffect DAP UUID |
| 下游依赖 | 无 | M4 是最终用户界面 |

### 1.3 技术规格

| 属性 | 规格 |
|------|------|
| 包名 | `com.dolby.atmos.oplus.folk` |
| 开发语言 | Kotlin 1.9+ |
| 最低 SDK | 34 (Android 14) |
| 目标 SDK | 35 (Android 15/16) |
| 架构模式 | MVVM (ViewModel + Repository + Service) |
| 依赖注入 | 手动依赖注入（避免引入 Hilt/Koin 增加 APK 体积） |
| 安装位置 | `/system/system_ext/priv-app/DolbyAtmosControl/` |
| 签名 | 系统 platform 签名 |
| 权限 | `MODIFY_DEFAULT_AUDIO_EFFECTS` (系统权限) |

---

## 2. 项目结构

```
com.dolby.atmos.oplus.folk/
├── DolbyApplication.kt                    # Application 入口
├── MainActivity.kt                        # 单 Activity 宿主
│
├── ui/
│   ├── main/
│   │   ├── MainFragment.kt               # 主控制面板
│   │   └── MainViewModel.kt              # 主面板状态管理
│   ├── equalizer/
│   │   ├── EqualizerFragment.kt          # 均衡器页面
│   │   └── EqualizerViewModel.kt         # 均衡器状态管理
│   ├── settings/
│   │   ├── SettingsFragment.kt           # 设置页面
│   │   └── SettingsViewModel.kt          # 设置状态管理
│   └── common/
│       ├── theme/
│       │   ├── Theme.kt                  # Material 3 主题
│       │   ├── Color.kt                  # 颜色定义
│       │   └── Type.kt                   # 字体样式
│       └── components/
│           ├── DolbySwitch.kt            # 杜比开关组件
│           ├── PresetCard.kt             # 预设模式卡片
│           ├── EqualizerSlider.kt        # 均衡器滑块
│           ├── DeviceStatusBar.kt        # 设备状态栏
│           └── LanguageSelector.kt       # 语言选择器
│
├── domain/
│   ├── model/
│   │   ├── DolbyState.kt                 # 杜比状态数据类
│   │   ├── Preset.kt                     # 预设模式枚举
│   │   ├── EqualizerBand.kt              # 均衡器频段
│   │   ├── AudioDevice.kt               # 音频输出设备
│   │   └── AppLanguage.kt               # 语言枚举
│   └── repository/
│       ├── DolbyRepository.kt            # 杜比数据仓库接口
│       └── SettingsRepository.kt         # 设置数据仓库接口
│
├── data/
│   ├── dms/
│   │   ├── DmsBinder.kt                  # DMS AIDL 绑定管理
│   │   ├── DmsRepositoryImpl.kt          # DMS 数据仓库实现
│   │   └── DmsParams.kt                  # DMS 参数常量
│   ├── audiofx/
│   │   ├── DapEffectController.kt        # AudioEffect API 封装
│   │   └── DvlEffectController.kt        # DVL 音量均衡控制
│   ├── device/
│   │   └── AudioDeviceMonitor.kt         # 音频设备状态监听
│   ├── preferences/
│   │   └── PreferencesManager.kt         # SharedPreferences 封装
│   └── local/
│       └── SettingsRepositoryImpl.kt     # 设置仓库实现
│
├── service/
│   ├── DolbyControlService.kt            # 前台服务（开机自启）
│   └── BootReceiver.kt                   # 开机广播接收器
│
└── i18n/
    ├── strings.xml                        # 英文默认字符串
    └── strings-zh.xml                     # 中文字符串
```

---

## 3. 类图

### 3.1 核心类图

```
┌──────────────────────┐
│   MainActivity       │
│   (single Activity)  │
│   hosts Fragments    │
└──────────┬───────────┘
           │ contains
           ▼
┌──────────────────────┐     ┌──────────────────────┐
│   MainFragment       │     │   MainViewModel      │
│   - dolbySwitch      │────▶│   - dolbyState: LvD  │
│   - presetCards      │     │   - currentPreset: LD│
│   - deviceStatus     │     │   - devices: LvD     │
└──────────────────────┘     └──────────┬───────────┘
                                        │ observes
                                        ▼
                              ┌──────────────────────┐
                              │   DolbyRepository    │
                              │   <<interface>>      │
                              │   + getState()       │
                              │   + setEnabled()     │
                              │   + setPreset()      │
                              │   + getDevices()     │
                              └──────────┬───────────┘
                                         │ implements
                    ┌────────────────────┼────────────────────┐
                    ▼                    ▼                    ▼
          ┌──────────────┐    ┌──────────────┐    ┌──────────────┐
          │DmsRepository │    │DapEffectCtrl │    │AudioDevice   │
          │Impl           │    │              │    │Monitor       │
          │(AIDL client) │    │(AudioEffect) │    │(AudioManager)│
          └──────────────┘    └──────────────┘    └──────────────┘
```

### 3.2 数据类

```kotlin
// domain/model/DolbyState.kt
data class DolbyState(
    val enabled: Boolean,
    val currentPreset: Preset,
    val availablePresets: List<Preset>,
    val activeDevice: AudioDevice,
    val sampleRate: Int,        // Hz
    val isDapActive: Boolean    // DAP 效果链是否真正激活
)

// domain/model/Preset.kt
enum class Preset(val id: Int, val nameResId: Int) {
    MOVIE(0, R.string.preset_movie),
    MUSIC(1, R.string.preset_music),
    GAME(2, R.string.preset_game),
    VOICE(3, R.string.preset_voice),
    CUSTOM(4, R.string.preset_custom)
}

// domain/model/EqualizerBand.kt
data class EqualizerBand(
    val index: Int,           // 0-9
    val frequencyHz: Int,     // 中心频率
    val gainDb: Float,        // -12.0 ~ +12.0 dB
    val isEnabled: Boolean
)

// domain/model/AudioDevice.kt
data class AudioDevice(
    val type: DeviceType,
    val name: String,         // 蓝牙设备名称（蓝牙时）
    val isConnected: Boolean
)

enum class DeviceType {
    SPEAKER, WIRED_HEADSET, BLUETOOTH_A2DP, BLUETOOTH_LE, USB_HEADSET, UNKNOWN
}

// domain/model/AppLanguage.kt
enum class AppLanguage(val code: String, val nameResId: Int) {
    SYSTEM("system", R.string.lang_system),
    CHINESE("zh", R.string.lang_chinese),
    ENGLISH("en", R.string.lang_english)
}
```

---

## 4. 关键类实现

### 4.1 `DolbyRepository.kt` — 仓库接口

```kotlin
// domain/repository/DolbyRepository.kt
interface DolbyRepository {
    /** 获取当前杜比状态 */
    suspend fun getState(): DolbyState

    /** 设置杜比开关 */
    suspend fun setEnabled(enabled: Boolean): Result<Unit>

    /** 切换预设模式 */
    suspend fun setPreset(preset: Preset): Result<Unit>

    /** 获取当前预设参数 */
    suspend fun getPresetParams(preset: Preset): Map<String, Any>

    /** 设置均衡器频段增益 */
    suspend fun setEqualizerBand(band: Int, gainDb: Float): Result<Unit>

    /** 获取均衡器全部频段 */
    suspend fun getEqualizerBands(): List<EqualizerBand>

    /** 监听音频设备变化 */
    fun observeDeviceChanges(): Flow<AudioDevice>

    /** 监听杜比状态变化 */
    fun observeDolbyState(): Flow<DolbyState>
}
```

### 4.2 `DapEffectController.kt` — AudioEffect API 封装

```kotlin
// data/audiofx/DapEffectController.kt
class DapEffectController(context: Context) {
    companion object {
        // DAP 效果 UUID (来自 audio_effects.xml)
        val DAP_UUID: UUID = UUID.fromString("9d4921da-8225-4f29-aefa-39537a04bcaa")
        private const val DAP_EFFECT_TYPE = "dap"

        // DAP 参数键
        private const val PARAM_ENABLE = 0x0001
        private const val PARAM_PRESET = 0x0002
        private const val PARAM_EQ_BAND = 0x0003
        private const val PARAM_SURROUND_LEVEL = 0x0004
        private const val PARAM_DIALOG_ENHANCE = 0x0005
        private const val PARAM_BASS_ENHANCE = 0x0006
        private const val PARAM_VOLUME_LEVELER = 0x0007
    }

    private var dapEffect: AudioEffect? = null
    private var isInitialized = false

    /**
     * 初始化 DAP 效果实例
     * 在后台线程调用
     */
    fun initialize(): Result<Unit> {
        return try {
            val descriptor = AudioEffect.Descriptor(
                DAP_EFFECT_TYPE,
                UUID.randomUUID().toString(), // type UUID (not used for existing effects)
                "Dolby Audio Processing",
                "Dolby Laboratories"
            )
            dapEffect = AudioEffect(
                AudioEffect.EFFECT_TYPE_NULL,
                DAP_UUID,
                0, // priority
                0  // audio session 0 = global output mix
            )
            isInitialized = dapEffect != null
            if (isInitialized) Result.success(Unit)
            else Result.failure(Exception("DAP effect not available"))
        } catch (e: Exception) {
            isInitialized = false
            Result.failure(e)
        }
    }

    /**
     * 启用/禁用 DAP 效果
     */
    fun setEnabled(enabled: Boolean): Result<Unit> {
        return try {
            val effect = dapEffect ?: return Result.failure(IllegalStateException("Not initialized"))
            effect.enabled = enabled
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 查询 DAP 是否启用
     */
    fun isEnabled(): Boolean {
        return dapEffect?.enabled ?: false
    }

    /**
     * 设置预设模式
     * @param presetId 0=电影, 1=音乐, 2=游戏, 3=语音, 4=自定义
     */
    fun setPreset(presetId: Int): Result<Unit> {
        return try {
            val effect = dapEffect ?: return Result.failure(IllegalStateException("Not initialized"))
            val param = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(presetId).array()
            val status = effect.setParameter(
                byteArrayOf(PARAM_PRESET.toByte(), 0x00, 0x00, 0x00),
                param
            )
            if (status == AudioEffect.SUCCESS) Result.success(Unit)
            else Result.failure(Exception("setPreset failed: status=$status"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 设置均衡器频段增益
     * @param band 频段索引 0-9
     * @param gainDb 增益值 -12.0 ~ +12.0 dB
     */
    fun setEqualizerBand(band: Int, gainDb: Float): Result<Unit> {
        return try {
            val effect = dapEffect ?: return Result.failure(IllegalStateException("Not initialized"))
            // 将 gainDb 转换为 millibel (整数)
            val mB = (gainDb * 100).toInt().coerceIn(-1200, 1200)
            val param = ByteBuffer.allocate(8)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(band)
                .putInt(mB)
                .array()
            val status = effect.setParameter(
                byteArrayOf(PARAM_EQ_BAND.toByte(), 0x00, 0x00, 0x00),
                param
            )
            if (status == AudioEffect.SUCCESS) Result.success(Unit)
            else Result.failure(Exception("setEqualizerBand failed: status=$status"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 释放资源
     */
    fun release() {
        dapEffect?.release()
        dapEffect = null
        isInitialized = false
    }
}
```

### 4.3 `DmsBinder.kt` — DMS AIDL 绑定管理

```kotlin
// data/dms/DmsBinder.kt
class DmsBinder(context: Context) {
    companion object {
        private const val DMS_SERVICE_NAME = "vendor.dolby.dms.IDms/default"
        private const val RETRY_DELAY_MS = 2000L
        private const val MAX_RETRIES = 5
    }

    private var dmsService: IDms? = null
    private var isConnected = false
    private val _connectionState = MutableStateFlow(false)
    val connectionState: StateFlow<Boolean> = _connectionState.asStateFlow()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            dmsService = IDms.Stub.asInterface(service)
            isConnected = true
            _connectionState.value = true
            Log.i("DmsBinder", "DMS service connected")
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            dmsService = null
            isConnected = false
            _connectionState.value = false
            Log.w("DmsBinder", "DMS service disconnected")
        }

        override fun onBindingDied(name: ComponentName?) {
            dmsService = null
            isConnected = false
            _connectionState.value = false
            Log.w("DmsBinder", "DMS service binding died")
        }
    }

    /**
     * 绑定 DMS 服务（带重试）
     */
    suspend fun bind(): Result<Unit> {
        var retries = 0
        while (retries < MAX_RETRIES) {
            try {
                val intent = Intent().apply {
                    component = ComponentName(
                        "vendor.dolby.dms",
                        "vendor.dolby.dms.IDms"
                    )
                }
                // 尝试通过 ServiceManager 直接获取
                val binder = ServiceManager.getService(DMS_SERVICE_NAME)
                if (binder != null) {
                    dmsService = IDms.Stub.asInterface(binder)
                    isConnected = true
                    _connectionState.value = true
                    return Result.success(Unit)
                }
            } catch (e: Exception) {
                Log.w("DmsBinder", "Bind attempt ${retries + 1} failed: ${e.message}")
            }
            retries++
            delay(RETRY_DELAY_MS)
        }
        return Result.failure(Exception("DMS service not available after $MAX_RETRIES retries"))
    }

    /**
     * 获取 DMS 服务接口（如果未连接则返回 null）
     */
    fun getService(): IDms? = if (isConnected) dmsService else null

    /**
     * 解绑
     */
    fun unbind() {
        dmsService = null
        isConnected = false
        _connectionState.value = false
    }
}
```

### 4.4 `MainViewModel.kt` — 主面板状态管理

```kotlin
// ui/main/MainViewModel.kt
class MainViewModel(
    private val dolbyRepository: DolbyRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    // ---- 暴露给 UI 的状态 ----
    private val _dolbyState = MutableStateFlow(DolbyState(
        enabled = false,
        currentPreset = Preset.MUSIC,
        availablePresets = Preset.entries,
        activeDevice = AudioDevice(DeviceType.SPEAKER, "", true),
        sampleRate = 48000,
        isDapActive = false
    ))
    val dolbyState: StateFlow<DolbyState> = _dolbyState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableSharedFlow<String>()
    val errorMessage: SharedFlow<String> = _errorMessage.asSharedFlow()

    // ---- 初始化 ----
    init {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val state = dolbyRepository.getState()
                _dolbyState.value = state
                // 从持久化存储恢复上次配置
                val savedEnabled = settingsRepository.getDolbyEnabled()
                if (savedEnabled != state.enabled) {
                    dolbyRepository.setEnabled(savedEnabled)
                }
                val savedPreset = settingsRepository.getCurrentPreset()
                if (savedPreset != state.currentPreset) {
                    dolbyRepository.setPreset(savedPreset)
                }
            } catch (e: Exception) {
                _errorMessage.emit("初始化失败: ${e.message}")
            } finally {
                _isLoading.value = false
            }
        }

        // 监听设备变化
        viewModelScope.launch {
            dolbyRepository.observeDeviceChanges().collect { device ->
                _dolbyState.update { it.copy(activeDevice = device) }
                // 设备切换时恢复该设备的配置
                val devicePreset = settingsRepository.getDevicePreset(device.type)
                if (devicePreset != null) {
                    setPreset(devicePreset)
                }
            }
        }

        // 监听状态变化
        viewModelScope.launch {
            dolbyRepository.observeDolbyState().collect { state ->
                _dolbyState.value = state
            }
        }
    }

    // ---- 用户操作 ----
    fun toggleDolby() {
        viewModelScope.launch {
            val newEnabled = !_dolbyState.value.enabled
            _dolbyState.update { it.copy(enabled = newEnabled) }
            val result = dolbyRepository.setEnabled(newEnabled)
            result.onFailure {
                _dolbyState.update { it.copy(enabled = !newEnabled) } // 回滚
                _errorMessage.emit("切换失败: ${it.message}")
            }
            result.onSuccess {
                settingsRepository.setDolbyEnabled(newEnabled)
            }
        }
    }

    fun setPreset(preset: Preset) {
        viewModelScope.launch {
            val previousPreset = _dolbyState.value.currentPreset
            _dolbyState.update { it.copy(currentPreset = preset) }
            val result = dolbyRepository.setPreset(preset)
            result.onFailure {
                _dolbyState.update { it.copy(currentPreset = previousPreset) } // 回滚
                _errorMessage.emit("切换预设失败: ${it.message}")
            }
            result.onSuccess {
                settingsRepository.setCurrentPreset(preset)
                settingsRepository.setDevicePreset(_dolbyState.value.activeDevice.type, preset)
            }
        }
    }
}
```

### 4.5 `EqualizerViewModel.kt` — 均衡器状态管理

```kotlin
// ui/equalizer/EqualizerViewModel.kt
class EqualizerViewModel(
    private val dolbyRepository: DolbyRepository
) : ViewModel() {

    // 10 段均衡器默认中心频率
    companion object {
        val DEFAULT_FREQUENCIES = intArrayOf(32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
        val DEFAULT_GAINS = floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)
    }

    private val _bands = MutableStateFlow(
        DEFAULT_FREQUENCIES.mapIndexed { index, freq ->
            EqualizerBand(index, freq, DEFAULT_GAINS[index], true)
        }
    )
    val bands: StateFlow<List<EqualizerBand>> = _bands.asStateFlow()

    private val _isDirty = MutableStateFlow(false)
    val isDirty: StateFlow<Boolean> = _isDirty.asStateFlow()

    init {
        viewModelScope.launch {
            val storedBands = dolbyRepository.getEqualizerBands()
            if (storedBands.isNotEmpty()) {
                _bands.value = storedBands
            }
        }
    }

    fun setBandGain(bandIndex: Int, gainDb: Float) {
        val clampedGain = gainDb.coerceIn(-12f, 12f)
        _bands.update { current ->
            current.map { if (it.index == bandIndex) it.copy(gainDb = clampedGain) else it }
        }
        _isDirty.value = true
        // 实时预览，立即应用
        viewModelScope.launch {
            dolbyRepository.setEqualizerBand(bandIndex, clampedGain)
        }
    }

    fun resetToFlat() {
        _bands.update { current ->
            current.map { it.copy(gainDb = 0f) }
        }
        _isDirty.value = true
        viewModelScope.launch {
            _bands.value.forEach { band ->
                dolbyRepository.setEqualizerBand(band.index, 0f)
            }
        }
    }

    fun applyPresetCurve(preset: Preset) {
        val curve = when (preset) {
            Preset.ROCK -> floatArrayOf(4f, 2f, -1f, -2f, 0f, 2f, 4f, 5f, 4f, 3f)
            Preset.POP -> floatArrayOf(-1f, -2f, 0f, 2f, 4f, 2f, 0f, -1f, -2f, 0f)
            Preset.CLASSICAL -> floatArrayOf(4f, 3f, 1f, 0f, -1f, -1f, 0f, 1f, 2f, 3f)
            Preset.JAZZ -> floatArrayOf(3f, 2f, 0f, 1f, -1f, -1f, 0f, 1f, 2f, 2f)
            Preset.VOCAL -> floatArrayOf(-2f, -3f, -3f, 0f, 2f, 3f, 3f, 2f, 0f, -1f)
            Preset.FLAT -> DEFAULT_GAINS
            else -> DEFAULT_GAINS
        }
        _bands.update { current ->
            current.mapIndexed { index, band ->
                band.copy(gainDb = curve.getOrElse(index) { 0f })
            }
        }
        _isDirty.value = true
        viewModelScope.launch {
            curve.forEachIndexed { index, gain ->
                dolbyRepository.setEqualizerBand(index, gain)
            }
        }
    }
}
```

### 4.6 `DolbyControlService.kt` — 开机自启服务

```kotlin
// service/DolbyControlService.kt
@AndroidEntryPoint
class DolbyControlService : Service() {
    private lateinit var dapController: DapEffectController
    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate() {
        super.onCreate()
        dapController = DapEffectController(this)
        preferencesManager = PreferencesManager(this)

        // 初始化 DAP 效果
        val result = dapController.initialize()
        if (result.isSuccess) {
            // 恢复上次的配置
            val wasEnabled = preferencesManager.getDolbyEnabled()
            dapController.setEnabled(wasEnabled)
            val lastPreset = preferencesManager.getCurrentPreset()
            dapController.setPreset(lastPreset.id)
            Log.i("DolbyControlService", "DAP initialized, enabled=$wasEnabled, preset=${lastPreset.name}")
        } else {
            Log.e("DolbyControlService", "DAP initialization failed")
        }

        // 启动前台通知
        startForeground(NOTIFICATION_ID, createNotification())
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        dapController.release()
        super.onDestroy()
    }

    private fun createNotification(): Notification {
        // 最低限度的前台服务通知
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Dolby Atmos")
            .setContentText("Audio processing active")
            .setSmallIcon(R.drawable.ic_dolby)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "dolby_service"
    }
}

// service/BootReceiver.kt
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = PreferencesManager(context)
            if (prefs.getAutoStart()) {
                val serviceIntent = Intent(context, DolbyControlService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            }
        }
    }
}
```

---

## 5. UI 布局

### 5.1 主控制面板 (`fragment_main.xml`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="?attr/colorSurface"
    android:padding="16dp">

    <!-- 顶部标题栏 -->
    <TextView
        android:id="@+id/tvTitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Dolby Atmos"
        android:textSize="28sp"
        android:textStyle="bold"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <!-- 杜比总开关 -->
    <com.google.android.material.materialswitch.MaterialSwitch
        android:id="@+id/switchDolby"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/dolby_enabled"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintTop_toTopOf="@id/tvTitle"
        app:layout_constraintBottom_toBottomOf="@id/tvTitle" />

    <!-- 设备状态栏 -->
    <com.dolby.atmos.oplus.folk.ui.common.components.DeviceStatusBar
        android:id="@+id/deviceStatusBar"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tvTitle" />

    <!-- 预设模式区域标题 -->
    <TextView
        android:id="@+id/tvPresetTitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="24dp"
        android:text="@string/presets"
        android:textSize="18sp"
        android:textStyle="bold"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/deviceStatusBar" />

    <!-- 预设模式卡片列表（横向滚动） -->
    <androidx.recyclerview.widget.RecyclerView
        android:id="@+id/rvPresets"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginTop="12dp"
        android:orientation="horizontal"
        app:layoutManager="androidx.recyclerview.widget.LinearLayoutManager"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintTop_toBottomOf="@id/tvPresetTitle" />

    <!-- 底部导航 -->
    <com.google.android.material.bottomnavigation.BottomNavigationView
        android:id="@+id/bottomNav"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        app:menu="@menu/bottom_nav"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>
```

### 5.2 均衡器页面 (`fragment_equalizer.xml`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">

    <!-- 均衡器预设曲线快捷选择 -->
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/eq_presets"
        android:textSize="16sp"
        android:textStyle="bold" />

    <HorizontalScrollView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="8dp">
        <LinearLayout
            android:id="@+id/llEqPresets"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="horizontal">
            <!-- 动态填充 Chip: 摇滚/流行/古典/爵士/人声/平坦 -->
        </LinearLayout>
    </HorizontalScrollView>

    <!-- 均衡器滑块区域 -->
    <androidx.constraintlayout.widget.ConstraintLayout
        android:id="@+id/clEqualizer"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"
        android:layout_marginTop="16dp">

        <!-- 10 段垂直滑块 -->
        <LinearLayout
            android:id="@+id/llSliders"
            android:layout_width="0dp"
            android:layout_height="0dp"
            android:orientation="horizontal"
            android:gravity="center"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintBottom_toTopOf="@id/llFreqLabels">
            <!-- 动态填充 EqualizerSlider -->
        </LinearLayout>

        <!-- 频率标签 -->
        <LinearLayout
            android:id="@+id/llFreqLabels"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintBottom_toBottomOf="parent">
            <!-- 32, 64, 125, 250, 500, 1k, 2k, 4k, 8k, 16k -->
        </LinearLayout>

    </androidx.constraintlayout.widget.ConstraintLayout>

    <!-- 重置按钮 -->
    <Button
        android:id="@+id/btnReset"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="center_horizontal"
        android:layout_marginTop="16dp"
        android:text="@string/eq_reset" />

</LinearLayout>
```

### 5.3 设置页面 (`fragment_settings.xml`)

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">

    <!-- 语言选择 -->
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/settings_language"
        android:textSize="18sp"
        android:textStyle="bold" />

    <com.dolby.atmos.oplus.folk.ui.common.components.LanguageSelector
        android:id="@+id/languageSelector"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="8dp" />

    <!-- 开机自启 -->
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="24dp"
        android:orientation="horizontal"
        android:gravity="center_vertical">
        <TextView
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:text="@string/settings_auto_start"
            android:textSize="16sp" />
        <com.google.android.material.materialswitch.MaterialSwitch
            android:id="@+id/switchAutoStart"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content" />
    </LinearLayout>

    <!-- 蓝牙独立配置 -->
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:orientation="horizontal"
        android:gravity="center_vertical">
        <TextView
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:text="@string/settings_bluetooth_independent"
            android:textSize="16sp" />
        <com.google.android.material.materialswitch.MaterialSwitch
            android:id="@+id/switchBtIndependent"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content" />
    </LinearLayout>

    <!-- 关于 -->
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="32dp"
        android:text="@string/settings_about"
        android:textSize="18sp"
        android:textStyle="bold" />

    <TextView
        android:id="@+id/tvAbout"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="8dp"
        android:textSize="14sp"
        android:textColor="?attr/colorOnSurfaceVariant" />

</LinearLayout>
```

---

## 6. 序列图

### 6.1 启动与初始化

```
User            BootReceiver      DolbyControlService    DapEffectController    DmsBinder
 │                   │                    │                      │                   │
 │  BOOT_COMPLETED   │                    │                      │                   │
 ├──────────────────▶│                    │                      │                   │
 │                   │  startService()    │                      │                   │
 │                   ├───────────────────▶│                      │                   │
 │                   │                    │  initialize()        │                   │
 │                   │                    ├─────────────────────▶│                   │
 │                   │                    │  AudioEffect(UUID)   │                   │
 │                   │                    │◀─────────────────────┤                   │
 │                   │                    │  success             │                   │
 │                   │                    │                      │                   │
 │                   │                    │  restore last state  │                   │
 │                   │                    │  (SharedPreferences) │                   │
 │                   │                    │                      │                   │
 │                   │                    │  bind()              │                   │
 │                   │                    ├──────────────────────────────────────────▶│
 │                   │                    │◀──────────────────────────────────────────┤
 │                   │                    │  DMS connected       │                   │
```

### 6.2 用户切换预设

```
User            MainFragment      MainViewModel       DolbyRepository    DapEffectController
 │                   │                  │                     │                    │
 │  tap "Movie"      │                  │                     │                    │
 ├──────────────────▶│                  │                     │                    │
 │                   │ setPreset(MOVIE) │                     │                    │
 │                   ├─────────────────▶│                     │                    │
 │                   │                  │ setPreset(MOVIE)    │                    │
 │                   │                  ├────────────────────▶│                    │
 │                   │                  │                     │ setPreset(0)       │
 │                   │                  │                     ├───────────────────▶│
 │                   │                  │                     │  success           │
 │                   │                  │                     │◀───────────────────┤
 │                   │                  │  Result.success     │                    │
 │                   │                  │◀────────────────────┤                    │
 │                   │  update UI       │                     │                    │
 │                   │◀─────────────────┤                     │                    │
 │  see highlight    │                  │                     │                    │
```

### 6.3 音频设备切换

```
System            AudioDeviceMonitor    DolbyRepository    MainViewModel    MainFragment
 │                       │                     │                  │              │
 │  BT headset connected │                     │                  │              │
 ├──────────────────────▶│                     │                  │              │
 │                       │ AudioDevice(BT,     │                  │              │
 │                       │  "Sony WH-1000XM5") │                  │              │
 │                       ├────────────────────▶│                  │              │
 │                       │                     │ deviceChanged    │              │
 │                       │                     ├─────────────────▶│              │
 │                       │                     │                  │ load device   │
 │                       │                     │                  │ preset from   │
 │                       │                     │                  │ SharedPrefs   │
 │                       │                     │                  │              │
 │                       │                     │                  │ setPreset()  │
 │                       │                     │                  ├──────────────▶│
 │                       │                     │                  │ (DapEffect)  │
 │                       │                     │                  │              │
 │                       │                     │                  │ update UI    │
 │                       │                     │                  ├──────────────▶│
 │                       │                     │                  │              │
 │  see "BT Headset"    │                     │                  │              │
 │  + device preset     │                     │                  │              │
```

---

## 7. 状态机

### 7.1 杜比效果状态机

```
                    ┌─────────────────┐
                    │    UNKNOWN      │
                    │  (初始状态)     │
                    └────────┬────────┘
                             │ initialize()
                             ▼
                    ┌─────────────────┐
        ┌───────────│    DISABLED     │◀──────────┐
        │           │  (效果未激活)   │           │
        │           └────────┬────────┘           │
        │                    │ setEnabled(true)   │
        │                    ▼                    │
        │           ┌─────────────────┐           │
        │           │    ENABLING     │           │
        │           │  (正在激活)     │           │
        │           └────────┬────────┘           │
        │                    │                    │
        │              ┌─────┴─────┐              │
        │              ▼           ▼              │
        │     ┌──────────┐  ┌──────────┐         │
        │     │  ACTIVE  │  │  ERROR   │         │
        │     │ (已激活) │  │ (激活失败)│         │
        │     └────┬─────┘  └──────────┘         │
        │          │                               │
        │          │ setEnabled(false)             │
        │          ▼                               │
        │     ┌─────────────┐    setEnabled(true)  │
        │     │  DISABLING  │──────────────────────┘
        │     │  (正在关闭) │
        │     └──────┬──────┘
        │            │
        └────────────┘
```

### 7.2 DMS 连接状态机

```
                    ┌─────────────────┐
                    │  DISCONNECTED   │
                    │  (未连接)       │
                    └────────┬────────┘
                             │ bind()
                             ▼
                    ┌─────────────────┐
                    │  CONNECTING     │
                    │  (正在连接)     │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              ▼              │              ▼
     ┌────────────┐          │     ┌────────────┐
     │  CONNECTED │          │     │   ERROR    │
     │  (已连接)  │          │     │  (连接失败) │
     └─────┬──────┘          │     └──────┬─────┘
           │                 │            │
           │ onBindingDied() │            │ retry (max 5)
           ▼                 │            ▼
     ┌────────────┐          │     ┌─────────────┐
     │  RECONNECT │          │     │  FALLBACK   │
     │  ING       │──────────┘     │  (AudioEff  │
     └────────────┘                │   ect only)  │
                                   └──────────────┘
```

---

## 8. 数据流图

```
┌──────────────────────────────────────────────────────────────────┐
│                          UI Layer                                 │
│                                                                    │
│  MainFragment          EqualizerFragment       SettingsFragment   │
│  ┌──────────┐          ┌──────────────┐        ┌──────────────┐  │
│  │ Switch   │          │ 10 Sliders   │        │ Language     │  │
│  │ Preset   │          │ Reset Button │        │ Auto Start   │  │
│  │ Device   │          │ EQ Presets   │        │ BT Config    │  │
│  └────┬─────┘          └──────┬───────┘        └──────┬───────┘  │
│       │                       │                       │           │
│       ▼                       ▼                       ▼           │
│  MainViewModel          EqualizerViewModel     SettingsViewModel  │
│       │                       │                       │           │
├───────┼───────────────────────┼───────────────────────┼───────────┤
│       │              Domain / Repository Layer                    │
│       │                       │                       │           │
│       ▼                       ▼                       ▼           │
│  DolbyRepository ◀────────────┼───────────────────────┘           │
│  (interface)                   │                                   │
│       │                       │                                   │
│       ▼                       │                                   │
│  ┌─────────────┐              │                                   │
│  │DmsRepository│              │                                   │
│  │Impl         │              │                                   │
│  └──────┬──────┘              │                                   │
│         │                     │                                   │
├─────────┼─────────────────────┼───────────────────────────────────┤
│         │         Data Layer  │                                   │
│         ▼                     ▼                                   │
│  ┌────────────┐    ┌──────────────────┐                           │
│  │ DmsBinder  │    │DapEffectCtrl     │                           │
│  │ (AIDL)     │    │(AudioEffect API) │                           │
│  └──────┬─────┘    └────────┬─────────┘                           │
│         │                   │                                     │
│         ▼                   ▼                                     │
│  ┌────────────┐    ┌──────────────────┐                           │
│  │ vendor.    │    │ AudioFlinger     │                           │
│  │ dolby.dms  │    │ (libswdap_sp.so) │                           │
│  └────────────┘    └──────────────────┘                           │
└──────────────────────────────────────────────────────────────────┘

Data Flow:
  ▶ Command: UI → ViewModel → Repository → DmsBinder/DapEffectCtrl → HAL
  ◀ Status:  HAL → DapEffectCtrl → Repository → ViewModel → UI (StateFlow)
  ◀ Device:  AudioManager → AudioDeviceMonitor → Repository → ViewModel → UI
```

---

## 9. 中英文国际化

### 9.1 `res/values/strings.xml` (默认英文)

```xml
<resources>
    <string name="app_name">Dolby Atmos</string>
    <string name="dolby_enabled">Dolby Atmos</string>
    <string name="presets">Presets</string>
    <string name="preset_movie">Movie</string>
    <string name="preset_music">Music</string>
    <string name="preset_game">Game</string>
    <string name="preset_voice">Voice</string>
    <string name="preset_custom">Custom</string>
    <string name="device_speaker">Speaker</string>
    <string name="device_headset">Wired Headset</string>
    <string name="device_bluetooth">Bluetooth</string>
    <string name="device_usb">USB Headset</string>
    <string name="sample_rate">%d kHz</string>
    <string name="dap_active">DAP Active</string>
    <string name="dap_inactive">DAP Inactive</string>
    <string name="eq_title">Equalizer</string>
    <string name="eq_presets">EQ Presets</string>
    <string name="eq_rock">Rock</string>
    <string name="eq_pop">Pop</string>
    <string name="eq_classical">Classical</string>
    <string name="eq_jazz">Jazz</string>
    <string name="eq_vocal">Vocal</string>
    <string name="eq_flat">Flat</string>
    <string name="eq_reset">Reset to Flat</string>
    <string name="settings_title">Settings</string>
    <string name="settings_language">Language</string>
    <string name="settings_auto_start">Auto-start on boot</string>
    <string name="settings_bluetooth_independent">Independent Bluetooth config</string>
    <string name="settings_about">About</string>
    <string name="lang_system">Follow System</string>
    <string name="lang_chinese">中文</string>
    <string name="lang_english">English</string>
    <string name="about_text">Dolby Atmos OnePlus folk popularization\nVersion: %s\n\nOpen source project\nhttps://github.com/dolby-atmos-oplus-folk</string>
    <string name="error_init_failed">Initialization failed</string>
    <string name="error_preset_failed">Failed to switch preset</string>
    <string name="error_toggle_failed">Failed to toggle Dolby</string>
</resources>
```

### 9.2 `res/values-zh/strings.xml` (中文)

```xml
<resources>
    <string name="app_name">杜比全景声</string>
    <string name="dolby_enabled">杜比全景声</string>
    <string name="presets">预设模式</string>
    <string name="preset_movie">电影</string>
    <string name="preset_music">音乐</string>
    <string name="preset_game">游戏</string>
    <string name="preset_voice">语音</string>
    <string name="preset_custom">自定义</string>
    <string name="device_speaker">扬声器</string>
    <string name="device_headset">有线耳机</string>
    <string name="device_bluetooth">蓝牙设备</string>
    <string name="device_usb">USB 耳机</string>
    <string name="sample_rate">%d kHz</string>
    <string name="dap_active">DAP 已激活</string>
    <string name="dap_inactive">DAP 未激活</string>
    <string name="eq_title">均衡器</string>
    <string name="eq_presets">均衡器预设</string>
    <string name="eq_rock">摇滚</string>
    <string name="eq_pop">流行</string>
    <string name="eq_classical">古典</string>
    <string name="eq_jazz">爵士</string>
    <string name="eq_vocal">人声</string>
    <string name="eq_flat">平坦</string>
    <string name="eq_reset">重置为平坦</string>
    <string name="settings_title">设置</string>
    <string name="settings_language">语言</string>
    <string name="settings_auto_start">开机自启</string>
    <string name="settings_bluetooth_independent">蓝牙设备独立配置</string>
    <string name="settings_about">关于</string>
    <string name="lang_system">跟随系统</string>
    <string name="lang_chinese">中文</string>
    <string name="lang_english">English</string>
    <string name="about_text">Dolby Atmos OnePlus folk popularization\n版本: %s\n\n开源项目\nhttps://github.com/dolby-atmos-oplus-folk</string>
    <string name="error_init_failed">初始化失败</string>
    <string name="error_preset_failed">切换预设失败</string>
    <string name="error_toggle_failed">切换杜比失败</string>
</resources>
```

---

## 10. 测试方案

### 10.1 单元测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| `DapEffectController.initialize()` | Mock AudioEffect | 返回 `Result.success` |
| `DapEffectController.setEnabled()` | Mock AudioEffect | 调用 `effect.enabled = true` |
| `DapEffectController.setPreset(0)` | Mock AudioEffect | 调用 `effect.setParameter` 且参数正确 |
| `MainViewModel.toggleDolby()` | Mock DolbyRepository | `dolbyState.enabled` 翻转 |
| `MainViewModel.setPreset()` 回滚 | Mock 失败 | 状态回滚到切换前 |
| `EqualizerViewModel.setBandGain()` | Mock DolbyRepository | 增益值 clamp 到 [-12, 12] |
| `EqualizerViewModel.resetToFlat()` | Mock DolbyRepository | 所有 band 增益为 0 |
| `PreferencesManager` 读写 | 真实 SharedPreferences | 读写一致 |
| `LanguageSelector` 切换 | 切换语言 | 界面文字立即更新 |

### 10.2 UI 测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| 主界面渲染 | 启动 Activity | 总开关、预设卡片、设备状态全部显示 |
| 开关切换 | 点击总开关 | 开关动画流畅，状态文字更新 |
| 预设切换 | 点击电影/音乐/游戏/语音/自定义 | 选中卡片高亮，当前预设更新 |
| 均衡器滑块 | 拖动滑块 | 增益值实时更新，dB 标签显示正确 |
| 均衡器预设 | 点击摇滚/流行/古典等 | 所有滑块位置更新 |
| 重置按钮 | 点击重置 | 所有滑块归零 |
| 语言切换 | 设置中切换语言 | 所有界面文字更新 |
| 横竖屏切换 | 旋转设备 | 布局不变形，滚动位置保持 |

### 10.3 集成测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| 实际 DAP 控制 | 在真机上安装，切换开关 | 音频有可感知的变化 |
| 插拔耳机 | 插入/拔出有线耳机 | 设备状态更新，配置切换 |
| 蓝牙连接 | 连接蓝牙耳机 | 设备名显示，独立配置加载 |
| 开机自启 | 重启设备 | 服务自动启动，恢复上次配置 |
| 与解码器共存 | 同时播放 AC-4 内容 | 解码正常 + 音效正常 |

### 10.4 异常测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| DMS 服务不可用 | 不启动 DMS 服务 | APK 不崩溃，降级到 AudioEffect only |
| DAP 效果不存在 | 在无杜比的设备上启动 | 显示错误提示，不崩溃 |
| 快速切换预设 | 连续点击多个预设 | 无 ANR，最终状态正确 |
| 内存压力 | 打开 APK 后反复切换页面 | 无内存泄漏 (LeakCanary) |

---

## 11. 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v1.0 | 2026-06-29 | 初始版本，MVVM 架构，DMS AIDL + AudioEffect API 双路径 |