# Dolby Atmos OnePlus folk popularization — 详细设计文档

> **版本:** v1.0 | **日期:** 2026-06-29 | **状态:** 设计完成

---

## 文档概述

本文档集是 Dolby Atmos OnePlus folk popularization KSU 模块的详细设计文档，基于需求文档 [PRD v1.0](../dolby-atmos-prd/dolby-atmos-prd.html) 编写。共包含 6 个独立模块的设计文档，每个模块可独立开发、测试和交付。

---

## 模块索引

| 模块 | 文档 | 职责 | 代码量 | 关键接口 |
|------|------|------|--------|----------|
| **M1** | [M1-ksu-module-framework.md](M1-ksu-module-framework.md) | KSU 模块打包框架 | ~500 行 Shell | `customize.sh`, `service.sh`, `post-fs-data.sh`, `module.prop` |
| **M2** | [M2-dolby-decoder.md](M2-dolby-decoder.md) | 杜比解码器 | ~200 行 XML + 预编译 .so | `media_codecs_c2.xml`, `c2_manifest_vendor_audio.xml` |
| **M3** | [M3-dolby-audio-effect.md](M3-dolby-audio-effect.md) | 杜比音效链 | ~300 行 Shell + XML | `merge_audio_effects()`, `audio_effects.xml`, DAP UUID |
| **M4** | [M4-config-apk.md](M4-config-apk.md) | 配置 APK | ~2000 行 Kotlin | `DapEffectController`, `DmsBinder`, `MainViewModel` |
| **M5** | [M5-diagnostics.md](M5-diagnostics.md) | 诊断工具 | ~400 行 Shell | `action.sh` (10 阶段诊断流程) |
| **M6** | [M6-compatibility.md](M6-compatibility.md) | 兼容性适配 | ~300 行 Shell | `compat.sh`, `pre_install_check()`, `select_dap_control_path()` |

---

## 模块依赖关系

```
M1 (模块框架)
 ├── M2 (解码器) ── 依赖 M1 的目录结构、权限、服务启动
 ├── M3 (音效链) ── 依赖 M1 的目录结构、权限；共享 M2 的 VINTF
 │    └── M4 (APK) ── 依赖 M3 的 DMS AIDL + DAP AudioEffect
 ├── M5 (诊断)   ── 依赖 M1 的环境变量
 └── M6 (兼容性) ── 被 M1 的 customize.sh source 引入
```

---

## 开发顺序建议

| 阶段 | 模块 | 时间 | 依赖 |
|------|------|------|------|
| Phase 1 | M1 + M6 + M2 | 1-2 周 | 无（M6 与 M1 同步开发） |
| Phase 2 | M3 + M5 | 2-4 周 | M1, M2 |
| Phase 3 | M4 | 3-4 周 | M1, M3 |
| Phase 4 | 集成测试 | 2-3 周 | 全部 |

**关键路径:** M1 → M3 → M4（M3 的音效链路修复是最大风险点）

---

## 模块间接口速查

### M1 提供给其他模块

| 接口 | 类型 | 说明 |
|------|------|------|
| `$MODPATH`, `$MODDIR` | 环境变量 | 模块安装/运行时根路径 |
| `ui_print()` | Shell 函数 | 安装日志输出 |
| `abort()` | Shell 函数 | 安装中止 |
| `perm_recursive()` | Shell 函数 | 递归权限设置 |
| `perm_one()` | Shell 函数 | 单文件权限设置 |
| `log()` | Shell 函数 | 运行时日志 |
| `start_once()` | Shell 函数 | 服务启动 |
| `wait_prop()` | Shell 函数 | 等待系统属性 |

### 其他模块提供给 M1

| 接口 | 提供者 | 说明 |
|------|--------|------|
| `merge_audio_effects()` | M3 | 合并现场 audio_effects.xml |
| `apply_sepolicy_patches()` | M6 | SELinux 策略补丁 |
| `pre_install_check()` | M6 | 安装前兼容性检测 |

### M3 提供给 M4

| 接口 | 类型 | 说明 |
|------|------|------|
| `vendor.dolby.dms.IDms` | AIDL | DMS 参数控制 |
| `9d4921da-8225-4f29-aefa-39537a04bcaa` | UUID | DAP AudioEffect 控制 |

---

## 文件清单汇总

最终模块 ZIP 包应包含以下文件（按照 M1-M6 贡献标注）：

```
dolby-atmos-op-folk-v1.0.0.zip
├── module.prop                                    [M1]
├── customize.sh                                   [M1]
├── post-fs-data.sh                                [M1]
├── service.sh                                     [M1]
├── system.prop                                    [M1]
├── uninstall.sh                                   [M1]
├── action.sh                                      [M5]
├── META-INF/
│   ├── com/google/android/
│   │   ├── update-binary                          [M1]
│   │   └── updater-script                         [M1]
│   ├── compat.sh                                  [M6]
│   └── sepolicy.rule                              [M6]
├── system/
│   ├── odm/etc/
│   │   ├── audio_effects.xml                      [M3]
│   │   └── media_codecs_c2.xml                    [M2]
│   ├── vendor/
│   │   ├── bin/hw/
│   │   │   ├── vendor.dolby.dms.service           [M3]
│   │   │   └── vendor.dolby_sp.media.c2@1.0-service [M2]
│   │   ├── etc/dolby/
│   │   │   └── multimedia_dolby_dax_dflt.xml      [M3]
│   │   ├── etc/vintf/manifest/
│   │   │   └── c2_manifest_vendor_audio.xml       [M2]
│   │   └── lib64/
│   │       ├── libcodec2_soft_ac4dec_sp.so        [M2]
│   │       ├── libcodec2_soft_ddpdec_sp.so        [M2]
│   │       ├── libcodec2_soft_common.so           [M2]
│   │       ├── libcodec2_store_dolby_sp.so        [M2]
│   │       ├── libdeccfg_sp.so                    [M2]
│   │       ├── libYokiScale.so                    [M2]
│   │       ├── libdlbdsservice_sp.so              [M3]
│   │       ├── libdapparamstorage_sp.so           [M3]
│   │       ├── libdlbpreg_sp.so                   [M3]
│   │       ├── libdmshal.so                       [M3]
│   │       ├── libspatializerparamstorage.so      [M3]
│   │       ├── vendor.dolby.dms-V1-ndk.so         [M3]
│   │       ├── vendor.dolby_sp.hardware.dmssp@2.0.so [M3]
│   │       └── soundfx/
│   │           ├── libswdap_sp.so                 [M3]
│   │           ├── libdlbvol_sp.so                [M3]
│   │           └── libswgamedap_sp.so             [M3]
│   └── system_ext/
│       ├── etc/permissions/
│       │   └── com.dolby.atmos.oplus.folk.xml     [M1]
│       └── priv-app/
│           └── DolbyAtmosControl/
│               └── DolbyAtmosControl.apk          [M4]
└── my_product/etc/permissions/
    └── oplus.product.features_audiox.xml           [M3]
```

---

## 设计决策记录

| 决策 | 选择 | 理由 |
|------|------|------|
| 开发深度 | 完整实现级 | 用户要求 C 级深度，包含完整 Shell 代码和 Kotlin 类实现 |
| 音效修复策略 | 主方案 AIDL/HIDL 兼容修复 | 用户选择 C，先按最可能原因设计主方案 |
| 输出格式 | 多个独立 Markdown | 用户选择 B，每个模块独立文档 |
| 测试方案 | 每个模块附带 | 用户选择 A，每个模块包含测试方案 |
| APK 设计深度 | 完整类图+序列图+UI+数据流+状态机 | 用户选择 C，全覆盖 |

---

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v1.0 | 2026-06-29 | 全部 6 个模块设计完成 |