# M6: 兼容性适配 — 详细设计文档

> **版本:** v1.0 | **日期:** 2026-06-29 | **状态:** 详细设计

---

## 1. 模块概述

### 1.1 职责

M6 负责跨设备、跨 Android 版本、跨 Root 方案的兼容性适配，包括：

- 安装时设备兼容性检测（芯片、SDK、架构、音频栈）
- 多机型参数差异适配（ACE5 / ACE5 Pro）
- 多 Root 方案适配（KSU / Magisk / APatch）
- SELinux 策略补丁注入
- 运行时状态探测与适配

### 1.2 依赖关系

| 方向 | 模块 | 说明 |
|------|------|------|
| 上游依赖 | 无 | M6 是横切关注点，贯穿所有模块 |
| 下游依赖 | M1, M2, M3 | M6 的函数被 M1 的 `customize.sh`、`service.sh` 调用 |

### 1.3 部署方式

M6 的核心函数以 `META-INF/compat.sh` 形式部署，被 M1 的 `customize.sh` 在安装时 `source` 引入。辅助函数以 Shell 函数形式嵌入到 `post-fs-data.sh` 和 `service.sh` 中。

---

## 2. `META-INF/compat.sh` — 安装时兼容性检测

```bash
#!/system/bin/sh
# ============================================================
# M6: compat.sh — 兼容性检测函数库
# 被 M1 的 customize.sh 在安装时 source 引入
# ============================================================

# ============================================================
# 1. 设备信息函数
# ============================================================

# 获取设备型号
get_device_model() {
  getprop ro.product.model 2>/dev/null || echo "unknown"
}

# 获取设备代号
get_device_code() {
  getprop ro.product.device 2>/dev/null || echo "unknown"
}

# 获取芯片平台
get_platform() {
  getprop ro.board.platform 2>/dev/null || getprop ro.hardware 2>/dev/null || echo "unknown"
}

# 获取 Android SDK 版本
get_sdk_version() {
  getprop ro.build.version.sdk 2>/dev/null || echo "0"
}

# 获取 Android 版本
get_android_version() {
  getprop ro.build.version.release 2>/dev/null || echo "unknown"
}

# ============================================================
# 2. 兼容性检测函数
# ============================================================

# 检测 Root 方案
detect_root_solution() {
  if [ -n "$KSU" ]; then
    echo "KSU"
  elif [ -n "$APATCH" ]; then
    echo "APatch"
  elif [ -n "$MAGISK_VER" ]; then
    echo "Magisk"
  else
    echo "Unknown"
  fi
}

# 检测是否为 OPlus 设备
is_oplus_device() {
  local oem="$(getprop ro.product.manufacturer 2>/dev/null)"
  case "$oem" in
    *"OnePlus"*|*"oneplus"*|*"OPPO"*|*"oplus"*|*"Oplus"*)
      return 0 ;;
    *)
      return 1 ;;
  esac
}

# 检测音频 HAL 栈类型
detect_audio_stack() {
  if [ -e "/vendor/lib64/libaconfig_storage_read_api_cc.so" ] || \
     [ -e "/odm/etc/vintf/manifest/dvs-aidl-service.xml" ]; then
    echo "AIDL"
  else
    echo "HIDL"
  fi
}

# 检测是否已安装冲突模块
detect_conflicts() {
  local conflicts=""
  local mod_dir="/data/adb/modules"

  # 检查 ViPER4Android
  [ -d "$mod_dir/ViPER4Android" ] && conflicts="$conflicts ViPER4Android"
  [ -d "$mod_dir/v4a" ] && conflicts="$conflicts ViPER4Android"

  # 检查 JamesDSP
  [ -d "$mod_dir/JamesDSP" ] && conflicts="$conflicts JamesDSP"
  [ -d "$mod_dir/jamesdsp" ] && conflicts="$conflicts JamesDSP"

  # 检查其他杜比模块
  [ -d "$mod_dir/dolbyatmos" ] && conflicts="$conflicts DolbyAtmos(other)"
  [ -d "$mod_dir/dolby_codec" ] && conflicts="$conflicts DolbyCodec(other)"
  [ -d "$mod_dir/dolbycodec2hidl" ] && conflicts="$conflicts DolbyCodec2HIDL(reference)"

  # 检查 Audio Modification Library
  [ -d "$mod_dir/aml" ] && conflicts="$conflicts AML"

  # 检查 Audio Compatibility Patch
  [ -d "$mod_dir/acp" ] && conflicts="$conflicts ACP"

  echo "$conflicts"
}

# 检测是否存在硬件杜比解码器
detect_hardware_dolby() {
  if grep -q "c2.dolby" /vendor/etc/media_codecs*.xml 2>/dev/null; then
    echo "yes"
  else
    echo "no"
  fi
}

# ============================================================
# 3. 安装前综合检测
# ============================================================

pre_install_check() {
  local errors=0

  # 3.1 SDK 版本检查
  local sdk="$(get_sdk_version)"
  if [ "$sdk" -lt 34 ]; then
    ui_print "  错误: Android 版本过低 (SDK $sdk, 最低要求 SDK 34)"
    errors=$((errors + 1))
  fi

  # 3.2 架构检查
  local cpu_abi="$(getprop ro.product.cpu.abi 2>/dev/null)"
  if [ "$cpu_abi" != "arm64-v8a" ]; then
    ui_print "  错误: 不支持的 CPU 架构 ($cpu_abi)"
    errors=$((errors + 1))
  fi

  # 3.3 冲突模块检查
  local conflicts="$(detect_conflicts)"
  if [ -n "$conflicts" ]; then
    ui_print "  警告: 检测到可能冲突的模块:$conflicts"
    ui_print "  建议先卸载上述模块"
  fi

  # 3.4 硬件解码器检查
  if [ "$(detect_hardware_dolby)" = "yes" ]; then
    ui_print "  注意: 设备已存在硬件杜比解码器，模块将覆盖"
  fi

  # 3.5 非 OPlus 设备警告
  if ! is_oplus_device; then
    ui_print "  警告: 非一加/OPPO 设备，兼容性未验证"
  fi

  return $errors
}

# ============================================================
# 4. SELinux 策略补丁
# ============================================================

apply_sepolicy_patches() {
  local MODDIR="$1"
  local patch_file="$MODDIR/META-INF/sepolicy.rule"

  if [ ! -f "$patch_file" ]; then
    return 0
  fi

  # 使用 magiskpolicy 注入策略
  if command -v magiskpolicy >/dev/null 2>&1; then
    magiskpolicy --live --apply "$patch_file" 2>/dev/null && \
      ui_print "  SELinux 策略补丁已应用"
  fi
}

# ============================================================
# 5. 多机型参数
# ============================================================

# 获取机型特定的 DAP 参数覆盖
get_device_dap_params() {
  local device_model="$(get_device_model)"
  local device_code="$(get_device_code)"

  case "$device_code" in
    "PKG110")
      # 一加 ACE5
      echo "speaker_channels=2"
      echo "headphone_channels=2"
      echo "bt_max_sampling_rate=48000"
      ;;
    "PKG120"|"PKG130")
      # 一加 ACE5 Pro (待确认)
      echo "speaker_channels=2"
      echo "headphone_channels=2"
      echo "bt_max_sampling_rate=96000"
      ;;
    *)
      # 默认参数
      echo "speaker_channels=2"
      echo "headphone_channels=2"
      echo "bt_max_sampling_rate=48000"
      ;;
  esac
}

# ============================================================
# 6. 运行时适配
# ============================================================

# 根据音频栈类型选择 DAP 控制路径
select_dap_control_path() {
  local audio_stack="$(detect_audio_stack)"
  local ctrl_path=""

  case "$audio_stack" in
    "AIDL")
      # Android 16+ AIDL 音频栈
      # 优先使用 AudioEffect API 直接控制 DAP
      # 如果 DMS 服务可用，则同时使用 DMS AIDL
      ctrl_path="audioeffect_primary_dms_fallback"
      ;;
    "HIDL")
      # HIDL 音频栈 (Android 14-15)
      # 使用 DMS HIDL 绑定
      ctrl_path="dms_hidl_primary_audioeffect_fallback"
      ;;
    *)
      ctrl_path="audioeffect_only"
      ;;
  esac

  echo "$ctrl_path"
}

# 检测运行时 DAP 可用性
check_dap_runtime() {
  # 检查 AudioFlinger 中是否注册了 DAP 效果
  if dumpsys media.audio_flinger 2>/dev/null | grep -q "9d4921da-8225-4f29-aefa-39537a04bcaa"; then
    echo "available"
  else
    echo "unavailable"
  fi
}

# 检测运行时解码器可用性
check_decoder_runtime() {
  if dumpsys media.codec2 2>/dev/null | grep -q "c2.dolby"; then
    echo "available"
  else
    echo "unavailable"
  fi
}
```

---

## 3. SELinux 策略规则

### 3.1 `META-INF/sepolicy.rule`

```
# Dolby Atmos OnePlus folk popularization
# SELinux 策略补丁

# 允许 DMS 服务访问 AudioFlinger
allow vendor_dolby_dms_service audioserver:binder { call transfer };
allow vendor_dolby_dms_service audioserver_service:service_manager { find };

# 允许 Codec2 HAL 服务访问 MediaCodec
allow vendor_dolby_sp_media_c2@1_0_service mediacodec:binder { call transfer };
allow vendor_dolby_sp_media_c2@1_0_service mediacodec_service:service_manager { find };

# 允许 DAP 效果库访问音频数据
allow vendor_dolby_dms_service audio_device:chr_file { read write ioctl };
allow vendor_dolby_dms_service vendor_file:file { execute read open getattr };

# 允许 DAP 写入数据目录
allow vendor_dolby_dms_service vendor_data_file:dir { create write add_name search };
allow vendor_dolby_dms_service vendor_data_file:file { create write read open getattr };
```

**设计说明:** 这些规则仅在 SELinux Enforcing 模式下需要。如果设备处于 Permissive 模式，规则自动跳过。规则的 `allow` 语句使用 `magiskpolicy` 语法，通过 `--live` 模式注入运行时策略。

---

## 4. 多机型适配矩阵

### 4.1 设备参数表

| 参数 | 一加 ACE5 (PKG110) | 一加 ACE5 Pro (待确认) |
|------|---------------------|------------------------|
| 芯片 | Snapdragon 8 Gen 3 (sm8650) | Snapdragon 8 Gen 3/4 |
| Android | 16 (SDK 35) | 15/16 (SDK 34/35) |
| 内核 | 6.1.141 | 6.1.x |
| 音频 HAL | AIDL | AIDL/HIDL (待确认) |
| 扬声器声道 | 2 | 2 |
| 蓝牙最大采样率 | 48kHz | 48/96kHz (待确认) |
| VINTF 版本 | 6.0 | 6.0 |
| SELinux | Enforcing | Enforcing |

### 4.2 差异适配策略

| 差异点 | 适配方式 |
|--------|----------|
| 蓝牙采样率 | 通过 `get_device_dap_params()` 返回不同参数，写入 DAP 配置 |
| Android 版本 | Android 15 使用 `vendor.dolby_sp.hardware.dmssp@2.0` HIDL，Android 16 使用 AIDL DMS |
| 音频 HAL 栈 | `select_dap_control_path()` 自动选择最优控制路径 |
| 芯片性能 | Snapdragon 8 Gen 4 可启用更高音质参数（如 96kHz 蓝牙） |

---

## 5. 测试方案

### 5.1 单元测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| `get_device_model()` | 在不同设备上执行 | 返回正确的设备型号 |
| `detect_root_solution()` | 在 KSU/Magisk/APatch 环境分别执行 | 输出正确方案名称 |
| `detect_audio_stack()` | 在 HIDL/AIDL 设备上分别执行 | 正确识别栈类型 |
| `detect_conflicts()` | 安装 ViPER4Android 后执行 | 检测到 ViPER4Android |
| `is_oplus_device()` | 在一加设备上执行 | 返回 true |
| `is_oplus_device()` | 在三星设备上执行 | 返回 false |
| `pre_install_check()` | 在 Android 13 设备上执行 | 返回错误（SDK < 34） |
| `get_device_dap_params()` | 在 PKG110 上执行 | 返回 ACE5 参数 |
| `select_dap_control_path()` | 在 AIDL 设备上执行 | 返回 `audioeffect_primary_dms_fallback` |

### 5.2 集成测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| KSU 安装 | 在 KSU 设备上安装 | 安装成功，无兼容性错误 |
| Magisk 安装 | 在 Magisk 设备上安装 | 安装成功，无兼容性错误 |
| APatch 安装 | 在 APatch 设备上安装 | 安装成功，无兼容性错误 |
| 冲突模块检测 | 安装 ViPER4Android 后安装本模块 | 安装时显示警告但不中止 |
| 非 OPlus 设备 | 在非一加设备上安装 | 显示警告，但不中止 |
| SELinux 策略 | 在 Enforcing 设备上安装 | 策略补丁成功应用 |
| 多机型参数 | 在 PKG110 和 PKG120 上安装 | 分别应用正确的设备参数 |

---

## 6. 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v1.0 | 2026-06-29 | 初始版本，6 大类兼容性检测函数 |