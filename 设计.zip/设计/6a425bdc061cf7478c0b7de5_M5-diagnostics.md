# M5: 诊断工具 — 详细设计文档

> **版本:** v1.0 | **日期:** 2026-06-29 | **状态:** 详细设计

---

## 1. 模块概述

### 1.1 职责

M5 提供模块级的可观测性与诊断能力，帮助用户和开发者快速定位问题：

- 一键采集 logcat、tombstone、dumpsys 等诊断信息
- 自动分类诊断报告（正常/警告/异常）
- 服务状态快照（DMS、Codec2 HAL、DAP 效果）
- 文件完整性校验
- 输出到 `/storage/emulated/0/dolbylog/` 供用户分享

### 1.2 依赖关系

| 方向 | 模块 | 说明 |
|------|------|------|
| 上游依赖 | M1 | 依赖 M1 的环境变量和模块目录结构 |
| 下游依赖 | 无 | M5 是纯诊断工具 |

### 1.3 执行方式

```bash
# 在终端中执行
su -c "/data/adb/modules/dolby_atmos_oplus_folk/action.sh"

# 或在 KSU Manager 中点击"操作"按钮触发
```

---

## 2. `action.sh` — 完整实现

```bash
#!/system/bin/sh
# ============================================================
# M5: action.sh — Dolby Atmos 模块诊断脚本
# 执行: su -c "sh /data/adb/modules/dolby_atmos_oplus_folk/action.sh"
# 输出: /storage/emulated/0/dolbylog/
# ============================================================
set -e

# ---- 路径定义 ----
MODDIR="${0%/*}"
OUTDIR="/storage/emulated/0/dolbylog"
TIMESTAMP="$(date '+%Y-%m-%d_%H-%M-%S')"
REPORT_FILE="$OUTDIR/dolby_report_${TIMESTAMP}.txt"
RAW_LOG="$OUTDIR/dolby_logcat_${TIMESTAMP}.txt"
DUMP_FILE="$OUTDIR/dolby_dumpsys_${TIMESTAMP}.txt"
TOMBSTONE_DIR="$(find /data/tombstones -maxdepth 1 -name 'tombstone_*' 2>/dev/null | head -1)"
CRASH_DIR="$OUTDIR/crash_${TIMESTAMP}"
EVENT_LOG="$OUTDIR/dolby_event_${TIMESTAMP}.txt"
STACK_TRACE="$OUTDIR/dolby_stack_${TIMESTAMP}.txt"

# ---- 初始化 ----
mkdir -p "$OUTDIR" 2>/dev/null
mkdir -p "$CRASH_DIR" 2>/dev/null

# ---- 日志函数 ----
log() { echo "[$(date '+%H:%M:%S')] $1" >> "$REPORT_FILE"; }
log_console() { echo "[$(date '+%H:%M:%S')] $1"; }

# ---- 工具函数 ----
file_exists() { [ -f "$1" ] && echo "存在" || echo "缺失"; }
service_running() { pidof "$1" >/dev/null 2>&1 && echo "运行中 (PID: $(pidof "$1"))" || echo "未运行"; }
prop_get() { getprop "$1" 2>/dev/null || echo "未设置"; }

# ============================================================
# 阶段 1: 系统信息采集
# ============================================================
log_console "===== Dolby Atmos 诊断 v1.0 ====="
log_console ""

log "================================================"
log " Dolby Atmos 诊断报告"
log " 生成时间: $(date '+%Y-%m-%d %H:%M:%S')"
log "================================================"
log ""

log "========== 1. 系统信息 =========="
log "设备型号: $(getprop ro.product.model)"
log "设备代号: $(getprop ro.product.device)"
log "制造商:   $(getprop ro.product.manufacturer)"
log "Android:  $(getprop ro.build.version.release) (SDK $(getprop ro.build.version.sdk))"
log "内核:     $(uname -r)"
log "芯片:     $(getprop ro.board.platform)"
log "架构:     $(getprop ro.product.cpu.abi)"
log "SELinux:  $(getenforce 2>/dev/null || echo '未知')"
log ""

# ============================================================
# 阶段 2: 模块状态检查
# ============================================================
log "========== 2. 模块状态 =========="
log ""

# 2.1 模块信息
log "--- 2.1 模块信息 ---"
if [ -f "$MODDIR/module.prop" ]; then
  log "模块 ID:      $(grep '^id=' "$MODDIR/module.prop" | cut -d= -f2)"
  log "模块版本:    $(grep '^version=' "$MODDIR/module.prop" | cut -d= -f2)"
  log "模块作者:    $(grep '^author=' "$MODDIR/module.prop" | cut -d= -f2)"
else
  log "模块信息: module.prop 缺失"
fi
log ""

# 2.2 安装信息
log "--- 2.2 安装记录 ---"
if [ -f "$MODDIR/.install_info" ]; then
  cat "$MODDIR/.install_info" >> "$REPORT_FILE"
else
  log "安装记录: 未找到 .install_info"
fi
log ""

# 2.3 音频栈类型
log "--- 2.3 音频栈类型 ---"
if [ -f "$MODDIR/.audio_stack_type" ]; then
  log "音频栈: $(cat "$MODDIR/.audio_stack_type")"
else
  log "音频栈: 未知"
fi
log ""

# ============================================================
# 阶段 3: 服务状态检查
# ============================================================
log "========== 3. 服务状态 =========="
log ""

# 3.1 Codec2 HAL 服务
log "--- 3.1 Codec2 HAL 服务 ---"
C2_NAME="vendor.dolby_sp.media.c2@1.0-service"
log "状态: $(service_running "$C2_NAME")"
if [ -x "$MODDIR/system/vendor/bin/hw/$C2_NAME" ]; then
  log "可执行文件: 存在且有执行权限"
else
  log "可执行文件: 缺失或无执行权限"
fi
log ""

# 3.2 DMS 服务
log "--- 3.2 DMS 服务 ---"
DMS_NAME="vendor.dolby.dms.service"
log "状态: $(service_running "$DMS_NAME")"
if [ -x "$MODDIR/system/vendor/bin/hw/$DMS_NAME" ]; then
  log "可执行文件: 存在且有执行权限"
else
  log "可执行文件: 缺失或无执行权限"
fi
log ""

# 3.3 HIDL 服务注册
log "--- 3.3 HIDL 服务注册 ---"
if command -v lshal >/dev/null 2>&1; then
  lshal debug android.hardware.media.c2@1.0::IComponentStore/default1 2>&1 | head -30 >> "$REPORT_FILE" || log "HIDL 服务未注册"
else
  log "lshal 不可用"
fi
log ""

# 3.4 AIDL 服务注册 (DMS)
log "--- 3.4 AIDL 服务注册 (DMS) ---"
if command -v service >/dev/null 2>&1; then
  service list 2>/dev/null | grep -i dolby >> "$REPORT_FILE" || log "DMS AIDL 服务未注册"
else
  log "service 命令不可用"
fi
log ""

# ============================================================
# 阶段 4: 文件完整性校验
# ============================================================
log "========== 4. 文件完整性 =========="
log ""

# 4.1 解码器库
log "--- 4.1 解码器库 ---"
log "libcodec2_soft_ac4dec_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/libcodec2_soft_ac4dec_sp.so")"
log "libcodec2_soft_ddpdec_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/libcodec2_soft_ddpdec_sp.so")"
log "libcodec2_soft_common.so: $(file_exists "$MODDIR/system/vendor/lib64/libcodec2_soft_common.so")"
log "libcodec2_store_dolby_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/libcodec2_store_dolby_sp.so")"
log "libdeccfg_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/libdeccfg_sp.so")"
log "libYokiScale.so: $(file_exists "$MODDIR/system/vendor/lib64/libYokiScale.so")"
log ""

# 4.2 DAP 音效库
log "--- 4.2 DAP 音效库 ---"
log "libswdap_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/soundfx/libswdap_sp.so")"
log "libdlbvol_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/soundfx/libdlbvol_sp.so")"
log "libswgamedap_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/soundfx/libswgamedap_sp.so")"
log ""

# 4.3 DMS 库
log "--- 4.3 DMS 库 ---"
log "libdlbdsservice_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/libdlbdsservice_sp.so")"
log "libdapparamstorage_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/libdapparamstorage_sp.so")"
log "libdlbpreg_sp.so: $(file_exists "$MODDIR/system/vendor/lib64/libdlbpreg_sp.so")"
log "libdmshal.so: $(file_exists "$MODDIR/system/vendor/lib64/libdmshal.so")"
log "libspatializerparamstorage.so: $(file_exists "$MODDIR/system/vendor/lib64/libspatializerparamstorage.so")"
log "vendor.dolby.dms-V1-ndk.so: $(file_exists "$MODDIR/system/vendor/lib64/vendor.dolby.dms-V1-ndk.so")"
log "vendor.dolby_sp.hardware.dmssp@2.0.so: $(file_exists "$MODDIR/system/vendor/lib64/vendor.dolby_sp.hardware.dmssp@2.0.so")"
log ""

# 4.4 配置文件
log "--- 4.4 配置文件 ---"
log "audio_effects.xml: $(file_exists "$MODDIR/system/odm/etc/audio_effects.xml")"
log "media_codecs_c2.xml: $(file_exists "$MODDIR/system/odm/etc/media_codecs_c2.xml")"
log "c2_manifest_vendor_audio.xml: $(file_exists "$MODDIR/system/vendor/etc/vintf/manifest/c2_manifest_vendor_audio.xml")"
log "multimedia_dolby_dax_dflt.xml: $(file_exists "$MODDIR/system/vendor/etc/dolby/multimedia_dolby_dax_dflt.xml")"
log "oplus.product.features_audiox.xml: $(file_exists "$MODDIR/my_product/etc/permissions/oplus.product.features_audiox.xml")"
log ""

# 4.5 APK
log "--- 4.5 APK ---"
log "DolbyAtmosControl.apk: $(file_exists "$MODDIR/system/system_ext/priv-app/DolbyAtmosControl/DolbyAtmosControl.apk")"
log ""

# ============================================================
# 阶段 5: 运行时检查
# ============================================================
log "========== 5. 运行时检查 =========="
log ""

# 5.1 DAP 数据目录
log "--- 5.1 DAP 数据目录 ---"
DAP_DATA="/data/vendor/dolby"
if [ -d "$DAP_DATA" ]; then
  log "目录存在: $DAP_DATA"
  log "权限: $(stat -c '%a %U:%G' "$DAP_DATA" 2>/dev/null || ls -ld "$DAP_DATA" | awk '{print $1, $3":"$4}')"
  log "文件数: $(find "$DAP_DATA" -type f 2>/dev/null | wc -l)"
else
  log "目录不存在: $DAP_DATA"
fi
log ""

# 5.2 系统属性
log "--- 5.2 系统属性 ---"
log "ro.oplus.audio.effect.type: $(prop_get ro.oplus.audio.effect.type)"
log "ro.oplus.audio.dolby.equalizer_support: $(prop_get ro.oplus.audio.dolby.equalizer_support)"
log ""

# 5.3 SELinux 上下文
log "--- 5.3 SELinux 上下文 ---"
VENDOR_LIB="$MODDIR/system/vendor/lib64"
if [ -f "$VENDOR_LIB/soundfx/libswdap_sp.so" ]; then
  log "libswdap_sp.so 上下文: $(ls -Z "$VENDOR_LIB/soundfx/libswdap_sp.so" 2>/dev/null | awk '{print $NF}')"
fi
if [ -f "$VENDOR_LIB/libdlbpreg_sp.so" ]; then
  log "libdlbpreg_sp.so 上下文: $(ls -Z "$VENDOR_LIB/libdlbpreg_sp.so" 2>/dev/null | awk '{print $NF}')"
fi
log ""

# 5.4 挂载点
log "--- 5.4 挂载点 ---"
log "VINTF manifest 挂载:"
mount | grep "c2_manifest_vendor_audio.xml" >> "$REPORT_FILE" 2>/dev/null || log "  未找到挂载点"
log "AudioX feature 挂载:"
mount | grep "oplus.product.features_audiox.xml" >> "$REPORT_FILE" 2>/dev/null || log "  未找到挂载点"
log ""

# 5.5 AudioFlinger 效果检查
log "--- 5.5 AudioFlinger 效果 ---"
if command -v dumpsys >/dev/null 2>&1; then
  dumpsys media.audio_flinger 2>/dev/null | grep -A5 -i dolby >> "$DUMP_FILE" || log "AudioFlinger 中未找到 Dolby 效果"
  dumpsys media.audio_flinger 2>/dev/null | grep -A2 "dap\|dlb\|swdap" >> "$DUMP_FILE" 2>/dev/null || log "DAP 效果在 AudioFlinger 中未激活"
  log "完整 dumpsys 输出: $DUMP_FILE"
else
  log "dumpsys 不可用"
fi
log ""

# 5.6 MediaCodec 解码器检查
log "--- 5.6 MediaCodec 解码器 ---"
if command -v dumpsys >/dev/null 2>&1; then
  dumpsys media.codec2 2>/dev/null | grep -A2 -i dolby >> "$DUMP_FILE" 2>/dev/null || log "Codec2 中未找到 Dolby 解码器"
  log "完整 Codec2 dumpsys 输出: $DUMP_FILE"
else
  log "dumpsys 不可用"
fi
log ""

# ============================================================
# 阶段 6: Logcat 采集
# ============================================================
log "========== 6. Logcat 采集 =========="
log "正在采集 logcat (最近 1000 行)..."

# 采集 Dolby 相关日志
logcat -d -t 1000 2>/dev/null | grep -iE "dolby|dap|dlb|dms|swdap|ac4|eac3|codec2.*dolby|AudioFlinger" > "$RAW_LOG" 2>/dev/null

LOG_LINES=$(wc -l < "$RAW_LOG" 2>/dev/null || echo 0)
log "采集到 $LOG_LINES 行 Dolby 相关日志"
log "完整日志: $RAW_LOG"
log ""

# 采集事件日志
logcat -b events -d -t 500 2>/dev/null | grep -iE "audio|dolby|media" > "$EVENT_LOG" 2>/dev/null
log "事件日志: $EVENT_LOG"
log ""

# ============================================================
# 阶段 7: Tombstone 分析
# ============================================================
log "========== 7. Tombstone 分析 =========="

if [ -n "$TOMBSTONE_DIR" ] && [ -f "$TOMBSTONE_DIR" ]; then
  # 筛选与 Dolby 相关的 tombstone
  grep -l -iE "dolby|dap|swdap|dms|codec2" /data/tombstones/tombstone_* 2>/dev/null | while read -r ts; do
    ts_name="$(basename "$ts")"
    cp "$ts" "$CRASH_DIR/$ts_name" 2>/dev/null
    log "相关 tombstone: $ts_name"
    # 输出关键信息
    grep -E "pid:|signal|backtrace:|Abort|Fatal" "$ts" 2>/dev/null | head -20 >> "$REPORT_FILE"
  done

  if [ -z "$(find "$CRASH_DIR" -type f 2>/dev/null)" ]; then
    log "未找到与 Dolby 相关的 tombstone"
  fi
else
  log "未找到 tombstone 文件"
fi
log ""

# 采集 ANR traces
ANR_TRACE="$(find /data/anr -name 'anr_*' -newer "$MODDIR/module.prop" 2>/dev/null | head -1)"
if [ -n "$ANR_TRACE" ]; then
  cp "$ANR_TRACE" "$CRASH_DIR/" 2>/dev/null
  log "ANR trace: $(basename "$ANR_TRACE")"
fi
log ""

# ============================================================
# 阶段 8: 包管理器状态
# ============================================================
log "========== 8. APK 状态 =========="
PKG_NAME="com.dolby.atmos.oplus.folk"
if command -v pm >/dev/null 2>&1; then
  pm list packages 2>/dev/null | grep "$PKG_NAME" >> "$REPORT_FILE" && log "APK 已安装: $PKG_NAME" || log "APK 未安装: $PKG_NAME"
  pm path "$PKG_NAME" 2>/dev/null >> "$REPORT_FILE" || log "APK 路径: 未知"
else
  log "pm 命令不可用"
fi
log ""

# ============================================================
# 阶段 9: 分类报告
# ============================================================
log "========== 9. 分类报告 =========="
log ""

# 9.1 统计
PASS_COUNT=0; WARN_COUNT=0; FAIL_COUNT=0

check_pass()  { PASS_COUNT=$((PASS_COUNT + 1)); log "  ✓ $1"; }
check_warn()  { WARN_COUNT=$((WARN_COUNT + 1)); log "  ⚠ $1"; }
check_fail()  { FAIL_COUNT=$((FAIL_COUNT + 1)); log "  ✗ $1"; }

# 核心服务
if pidof "$C2_NAME" >/dev/null 2>&1; then check_pass "Codec2 HAL 服务运行中"; else check_fail "Codec2 HAL 服务未运行"; fi
if pidof "$DMS_NAME" >/dev/null 2>&1; then check_pass "DMS 服务运行中"; else check_warn "DMS 服务未运行（可能使用 AudioEffect only 模式）"; fi

# 解码器
if [ -f "$MODDIR/system/vendor/lib64/libcodec2_soft_ac4dec_sp.so" ]; then check_pass "AC-4 解码器库存在"; else check_fail "AC-4 解码器库缺失"; fi
if [ -f "$MODDIR/system/vendor/lib64/libcodec2_soft_ddpdec_sp.so" ]; then check_pass "E-AC-3 解码器库存在"; else check_fail "E-AC-3 解码器库缺失"; fi

# 音效
if [ -f "$MODDIR/system/vendor/lib64/soundfx/libswdap_sp.so" ]; then check_pass "DAP 音效库存在"; else check_fail "DAP 音效库缺失"; fi
if [ -f "$MODDIR/system/vendor/lib64/soundfx/libdlbvol_sp.so" ]; then check_pass "DVL 音量均衡库存在"; else check_warn "DVL 音量均衡库缺失"; fi

# 配置
if [ -f "$MODDIR/system/odm/etc/audio_effects.xml" ]; then check_pass "audio_effects.xml 存在"; else check_fail "audio_effects.xml 缺失"; fi
if [ -f "$MODDIR/system/odm/etc/media_codecs_c2.xml" ]; then check_pass "media_codecs_c2.xml 存在"; else check_fail "media_codecs_c2.xml 缺失"; fi

# 运行时
if [ -d "$DAP_DATA" ]; then check_pass "DAP 数据目录存在"; else check_warn "DAP 数据目录不存在"; fi
if [ "$(getprop ro.oplus.audio.effect.type 2>/dev/null)" = "dolby" ]; then check_pass "系统属性已设置"; else check_warn "系统属性未设置"; fi

# APK
if pm list packages 2>/dev/null | grep -q "$PKG_NAME"; then check_pass "APK 已安装"; else check_warn "APK 未安装"; fi

log ""
log "========== 9.1 诊断结果 =========="
log "通过: $PASS_COUNT"
log "警告: $WARN_COUNT"
log "失败: $FAIL_COUNT"
log ""

# 9.2 建议
log "========== 9.2 建议 =========="
if [ "$FAIL_COUNT" -gt 0 ]; then
  log "! 存在 $FAIL_COUNT 个失败项，请检查文件完整性或重新安装模块"
fi
if [ "$WARN_COUNT" -gt 0 ]; then
  log "! 存在 $WARN_COUNT 个警告项，建议检查相关配置"
fi
if [ "$FAIL_COUNT" -eq 0 ] && [ "$WARN_COUNT" -eq 0 ]; then
  log "所有检查通过，模块运行正常"
fi

# ============================================================
# 阶段 10: 日志打包
# ============================================================
log ""
log "========== 10. 日志文件 =========="
log "诊断报告: $REPORT_FILE"
log "Logcat 日志: $RAW_LOG"
log "Dumpsys 输出: $DUMP_FILE"
log "事件日志: $EVENT_LOG"
log "崩溃日志: $CRASH_DIR/"
log ""
log "可将以上文件分享给开发者以协助诊断"
log ""
log "================================================"
log " 诊断完成"
log "================================================"

# ---- 控制台输出摘要 ----
log_console ""
log_console "===== 诊断完成 ====="
log_console "通过: $PASS_COUNT | 警告: $WARN_COUNT | 失败: $FAIL_COUNT"
log_console "报告: $REPORT_FILE"
log_console ""

exit 0
```

---

## 3. 诊断分类参考

| 组件 | 检查项 | 正常 | 警告 | 异常 |
|------|--------|------|------|------|
| Codec2 HAL | 进程存在 | PID 存在 | - | PID 不存在 |
| Codec2 HAL | 库文件 | 6 个文件全部存在 | - | 任意文件缺失 |
| DMS | 进程存在 | PID 存在 | PID 不存在 | - |
| DMS | 库文件 | 7 个文件全部存在 | - | 任意文件缺失 |
| DAP | 效果库 | 3 个文件全部存在 | - | `libswdap_sp.so` 缺失 |
| DAP | 效果注册 | AudioFlinger 中有 DAP | - | AudioFlinger 中无 DAP |
| 配置 | audio_effects | 存在且包含 DAP UUID | - | 缺失或不含 DAP |
| 配置 | media_codecs | 存在且包含 Dolby 解码器 | - | 缺失或不含 Dolby |
| 运行时 | DAP 数据目录 | 存在且权限正常 | 不存在 | - |
| 运行时 | 系统属性 | `ro.oplus.audio.effect.type=dolby` | 未设置 | 设置为其他值 |
| APK | 安装状态 | 已安装 | 未安装 | - |
| SELinux | 库上下文 | `vendor_file` | 其他 | `unlabeled` |

---

## 4. 测试方案

### 4.1 单元测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| 脚本执行 | 在有模块安装的设备上运行 | 脚本正常完成，退出码 0 |
| 输出目录创建 | 运行后检查 | `/storage/emulated/0/dolbylog/` 存在 |
| 报告文件生成 | 运行后检查 | 报告文件存在且非空 |
| 文件完整性检查 | 删除一个 .so 后运行 | 报告显示该文件为"缺失" |
| 服务状态检查 | 停止 DMS 服务后运行 | 报告显示 DMS 为"未运行" |
| Logcat 采集 | 运行后检查 raw log 文件 | 文件包含 Dolby 相关日志 |
| 分类统计 | 运行后检查分类结果 | 正常/警告/失败计数正确 |

### 4.2 集成测试

| 测试项 | 测试方法 | 通过标准 |
|--------|----------|----------|
| 全部正常 | 模块完全正常安装后运行 | 全部通过，无失败 |
| 部分缺失 | 删除部分库后运行 | 准确报告缺失项 |
| 无 DMS 模式 | M3 不启动 DMS 时运行 | DMS 未运行标记为警告（非失败） |
| 无 root 运行 | 无 root 权限运行 | 优雅失败，提示需要 root |

---

## 5. 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v1.0 | 2026-06-29 | 初始版本，10 阶段诊断流程 |