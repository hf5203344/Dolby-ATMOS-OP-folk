# Dolby Atmos OnePlus folk popularization — Vibe Coding Prompt

> **目标:** 自动化实现 Dolby Atmos KSU 模块的全部 6 个模块，无需人工参与
> **输入:** `doc/proposal.md` (需求), `doc/detailed-design/` (详细设计), `doc/tasks/` (任务划分)

---

## 工程概述

本工程是一个面向一加 ACE5 (PKG110) 的 Dolby Atmos KSU Root 模块，包含杜比全景声解码器、音效引擎和配置 APK。共 6 个独立模块，按 M1/M6/M2 → M3/M5 → M4 顺序开发。

**技术栈:**
- Shell (POSIX sh) — M1、M3、M5、M6 的安装/启动/诊断脚本
- XML — M2、M3 的配置文件
- Kotlin (Android) — M4 的配置 APK
- 预编译 .so 二进制 — M2、M3 的原生库（从参考模块提取，SHA256 校验）

---

## 主 Agent 职责

主 Agent 负责整体进度跟踪，**不直接编写代码**。其职责：

1. 读取 `doc/tasks/progress.md` 了解当前进度
2. 按 Phase 顺序依次派发子 Agent：
   - **Phase 1:** M1 + M6 + M2（可并行 3 个子 Agent）
   - **Phase 2:** M3 + M5（可并行 2 个子 Agent）
   - **Phase 3:** M4（1 个子 Agent）
   - **Phase 4:** 集成测试（1 个子 Agent）
3. 每个子 Agent 完成后，更新 `doc/tasks/progress.md` 和对应模块的 `tasks/*.md` 中的 checkbox
4. 验证子 Agent 的输出满足质量门禁
5. 整个流程**不会有人工参与**，遇到阻塞时自行决策并记录

---

## 子 Agent 通用规范

每个子 Agent 实现一个模块，必须遵循：

### 代码质量门禁

| 文件类型 | 静态检查 | 测试框架 | 通过标准 |
|----------|----------|----------|----------|
| `.sh` 文件 | `shellcheck -s sh` | `bats` (Bash Automated Testing System) | 0 error, 0 warning |
| `.xml` 文件 | `xmllint --noout` | 结构验证 + XPath 断言 | 格式合法，关键节点存在 |
| `.kt` 文件 | `detekt` + `ktlint` | JUnit 5 (MockK + Turbine) | 0 error, 所有测试通过 |
| `.so` 文件 | SHA256 校验 | 在目标设备上 `dumpsys media.codec2` 验证 | 解码器注册成功，无 crash |
| 模块 ZIP 包 | `zip -T` 完整性检查 | KSU Manager 安装 + 重启 | 安装成功，设备正常开机 |

### 测试要求

- **Shell 脚本:** 每个公开函数必须有对应的 `bats` 测试用例，覆盖正常路径和异常路径
- **Kotlin 代码:** `ViewModel` 和 `Repository` 必须有 JUnit 单元测试，Mock 所有外部依赖。`DapEffectController`、`DmsBinder` 使用 MockK 模拟
- **XML 配置:** 必须有结构验证脚本（`xmllint` 格式检查 + XPath 关键节点存在性）
- **预编译 .so:** 必须有 SHA256 完整性校验脚本

### 输出规范

每个子 Agent 完成后的输出文件必须放入以下路径：

```
/workspace/build/
├── M1/
│   ├── module.prop
│   ├── customize.sh
│   ├── post-fs-data.sh
│   ├── service.sh
│   ├── system.prop
│   ├── uninstall.sh
│   ├── META-INF/
│   │   ├── com/google/android/
│   │   │   ├── update-binary
│   │   │   └── updater-script
│   │   └── compat.sh -> ../M6/META-INF/compat.sh  (symlink)
│   └── test/
│       ├── test_customize.bats
│       ├── test_service.bats
│       └── ...
├── M2/
│   ├── system/odm/etc/media_codecs_c2.xml
│   ├── system/vendor/etc/vintf/manifest/c2_manifest_vendor_audio.xml
│   ├── system/vendor/bin/hw/vendor.dolby_sp.media.c2@1.0-service
│   ├── system/vendor/lib64/libcodec2_soft_ac4dec_sp.so
│   ├── system/vendor/lib64/libcodec2_soft_ddpdec_sp.so
│   ├── system/vendor/lib64/libcodec2_soft_common.so
│   ├── system/vendor/lib64/libcodec2_store_dolby_sp.so
│   ├── system/vendor/lib64/libdeccfg_sp.so
│   ├── system/vendor/lib64/libYokiScale.so
│   ├── checksums.txt
│   └── test/
│       ├── validate_media_codecs.sh
│       └── ...
├── M3/
│   ├── system/odm/etc/audio_effects.xml
│   ├── system/vendor/bin/hw/vendor.dolby.dms.service
│   ├── system/vendor/etc/dolby/multimedia_dolby_dax_dflt.xml
│   ├── system/vendor/lib64/*.so  (7 个 DMS 库)
│   ├── system/vendor/lib64/soundfx/*.so  (3 个 DAP 库)
│   ├── my_product/etc/permissions/oplus.product.features_audiox.xml
│   ├── merge_audio_effects.sh  (独立测试用)
│   └── test/
│       ├── test_merge_audio_effects.bats
│       └── ...
├── M4/
│   ├── DolbyAtmosControl/  (完整 Android 项目)
│   │   ├── app/src/main/java/com/dolby/atmos/oplus/folk/
│   │   ├── app/src/test/java/com/dolby/atmos/oplus/folk/
│   │   └── ...
│   ├── system/system_ext/priv-app/DolbyAtmosControl/DolbyAtmosControl.apk
│   └── test/
│       └── ...
├── M5/
│   ├── action.sh
│   └── test/
│       ├── test_action.bats
│       └── ...
├── M6/
│   ├── META-INF/compat.sh
│   ├── META-INF/sepolicy.rule
│   └── test/
│       ├── test_compat.bats
│       └── ...
└── dolby-atmos-op-folk-v1.0.0.zip  (Phase 4 集成阶段生成)
```

---

## 子 Agent 详细指令

### M1 子 Agent: KSU 模块打包框架

**输入:** `doc/detailed-design/M1-ksu-module-framework.md`, `doc/tasks/M1-ksu-module-framework.md`

**任务:**
1. 按任务列表逐项实现所有 Shell 脚本文件
2. 每个 `.sh` 文件通过 `shellcheck -s sh` 零错误零警告
3. 编写 `bats` 测试用例覆盖所有公开函数（`ui_print`、`abort`、`perm_recursive`、`perm_one`、`start_once`、`wait_prop`、`detect_*` 系列）
4. 测试用例覆盖正常路径和异常路径（如权限不足、文件不存在、设备不兼容）

**质量门禁:**
```bash
shellcheck -s sh customize.sh post-fs-data.sh service.sh uninstall.sh
bats test/*.bats
```

---

### M2 子 Agent: 杜比解码器

**输入:** `doc/detailed-design/M2-dolby-decoder.md`, `doc/tasks/M2-dolby-decoder.md`

**任务:**
1. 编写 `media_codecs_c2.xml` 和 `c2_manifest_vendor_audio.xml`
2. 从参考模块 `/data/user/work/dolby_ref/` 提取 6 个 `.so` 文件和 1 个 HIDL 服务二进制
3. 计算所有二进制文件的 SHA256，写入 `checksums.txt`
4. 编写 XML 结构验证脚本（`xmllint` + XPath 断言）
5. 编写 SHA256 完整性校验脚本

**质量门禁:**
```bash
xmllint --noout system/odm/etc/media_codecs_c2.xml
xmllint --noout system/vendor/etc/vintf/manifest/c2_manifest_vendor_audio.xml
sh test/validate_media_codecs.sh
sh test/verify_checksums.sh
```

---

### M3 子 Agent: 杜比音效链

**输入:** `doc/detailed-design/M3-dolby-audio-effect.md`, `doc/tasks/M3-dolby-audio-effect.md`

**任务:**
1. 编写 `audio_effects.xml` 静态模板
2. 实现 `merge_audio_effects()` 函数（独立 Shell 脚本 + 内嵌 awk 合并逻辑）
3. 编写 `oplus.product.features_audiox.xml`
4. 从参考模块提取 DMS 服务二进制、7 个 DMS 库、3 个 DAP 库、调音参数 XML
5. 编写 `bats` 测试用例覆盖合并逻辑（正常合并、幂等性、损坏 XML 回退、AudioX 效果移除）

**质量门禁:**
```bash
shellcheck -s sh merge_audio_effects.sh
xmllint --noout system/odm/etc/audio_effects.xml
bats test/test_merge_audio_effects.bats
```

---

### M4 子 Agent: 配置 APK

**输入:** `doc/detailed-design/M4-config-apk.md`, `doc/tasks/M4-config-apk.md`

**任务:**
1. 创建完整 Android 项目（Kotlin, minSdk=34, targetSdk=35）
2. 实现数据层：`DapEffectController`、`DmsBinder`、`DmsRepositoryImpl`、`PreferencesManager`
3. 实现 Domain 层：`DolbyState`、`Preset`、`EqualizerBand`、`AudioDevice`、`DolbyRepository`
4. 实现 UI 层：`MainViewModel`、`EqualizerViewModel`、`SettingsViewModel`、3 个 Fragment
5. 实现 Service 层：`DolbyControlService`、`BootReceiver`
6. 中英文 i18n (`strings.xml` + `strings-zh.xml`)
7. 编写 JUnit 测试用例（MockK 模拟 `AudioEffect` 和 `IDms`）

**质量门禁:**
```bash
./gradlew detekt ktlintCheck
./gradlew test
```

**注意事项:**
- `DapEffectController` 和 `DmsBinder` 依赖 Android 系统 API（`AudioEffect`、`ServiceManager`），测试中使用 MockK `mockkStatic` 模拟
- `MainViewModel` 测试使用 `Turbine` 验证 `StateFlow` 行为
- APK 最终以 `system/system_ext/priv-app/DolbyAtmosControl/DolbyAtmosControl.apk` 输出

---

### M5 子 Agent: 诊断工具

**输入:** `doc/detailed-design/M5-diagnostics.md`, `doc/tasks/M5-diagnostics.md`

**任务:**
1. 实现完整的 `action.sh`（10 阶段诊断流程）
2. 编写 `bats` 测试用例覆盖所有工具函数和分类逻辑
3. 测试用例覆盖：正常设备、缺失文件、服务停止、无 root 权限

**质量门禁:**
```bash
shellcheck -s sh action.sh
bats test/test_action.bats
```

---

### M6 子 Agent: 兼容性适配

**输入:** `doc/detailed-design/M6-compatibility.md`, `doc/tasks/M6-compatibility.md`

**任务:**
1. 实现 `compat.sh`（6 大类检测函数 + 运行时适配函数）
2. 编写 `sepolicy.rule`（SELinux 策略规则）
3. 编写 `bats` 测试用例覆盖所有检测函数（正常/异常/边界）

**质量门禁:**
```bash
shellcheck -s sh META-INF/compat.sh
bats test/test_compat.bats
```

---

### Phase 4 子 Agent: 集成测试与打包

**输入:** `/workspace/build/` 下所有模块的输出

**任务:**
1. 合并所有模块文件到统一的 ZIP 包结构
2. 验证最终 ZIP 包的文件完整性（`zip -T`）
3. 在模拟环境中执行端到端安装流程验证
4. 生成最终发布清单

**质量门禁:**
```bash
zip -T dolby-atmos-op-folk-v1.0.0.zip
sh test/test_e2e_install.sh
```

---

## 主 Agent 工作流

```
开始
 │
 ├─[Phase 1] 并行派发 M1, M6, M2 子 Agent
 │   ├─ 等待全部完成
 │   ├─ 验证质量门禁
 │   └─ 更新 progress.md
 │
 ├─[Phase 2] 并行派发 M3, M5 子 Agent
 │   ├─ 等待全部完成
 │   ├─ 验证质量门禁
 │   └─ 更新 progress.md
 │
 ├─[Phase 3] 派发 M4 子 Agent
 │   ├─ 等待完成
 │   ├─ 验证质量门禁
 │   └─ 更新 progress.md
 │
 ├─[Phase 4] 派发集成测试子 Agent
 │   ├─ 等待完成
 │   ├─ 验证最终 ZIP 包
 │   └─ 更新 progress.md
 │
 └─ 完成
```

---

## 约束与规则

1. **禁止人工参与:** 整个流程自动执行，子 Agent 遇到阻塞时自行决策（记录决策理由），不得等待用户输入
2. **依赖顺序:** M6 必须在 M1 之前或同时完成（M1 source 引入 M6 的 compat.sh）；M3 必须在 M4 之前完成（M4 依赖 M3 的 DAP UUID）
3. **并行限制:** 同一时间最多 3 个子 Agent 并行执行
4. **文件路径:** 所有输出统一放在 `/workspace/build/` 下，不要在 `/workspace/` 根目录散落文件
5. **参考模块:** 预编译二进制从 `/data/user/work/dolby_ref/` 提取，不得自行编译
6. **质量门禁:** 任何子 Agent 未通过质量门禁，主 Agent 必须要求其重试（最多 3 次）
7. **进度更新:** 每完成一个模块，必须更新 `doc/tasks/progress.md` 和对应 `tasks/*.md` 中的 checkbox